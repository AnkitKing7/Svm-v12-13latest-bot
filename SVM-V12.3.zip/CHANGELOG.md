# Changelog

## V13.0 (2026-10-22) — SVM Advanced AI V13 — Made by AnkitCoder

### Added
- `svm_ipam.py`: unified IPAM with full lifecycle states, overlap detection, concurrent-safe allocation, health labels (RECORDED/INSTALLED/VERIFIED/DRIFT)
- `svm_net.py`: networking backend capability detection, dry-run apply, owned iptables comments (SVM-V13:…), diagnostic snapshot
- `svm_ssh.py`: structured SSH states, Termius/OpenSSH connection profiles, local sshd detection, auth test helpers
- Installer subcommands: `upgrade`, `backup`, `test`; pre-v13 timestamped backups; env key merge (never overwrite)
- Migration 13001 (additive IPAM columns + svm_schema_migrations)
- Unit tests: `tests/test_ipam_v13.py`, `tests/test_ssh_net_v13.py`
- `V13_UPGRADE.md` operational guide
- Configurable `BOT_OWNER_IMAGE_URL` / `BOT_BANNER_IMAGE_URL`

### Changed
- Default `BOT_VERSION=13.0`, `BOT_NAME=SVM Advanced AI V13`
- ACTIVE mappings require backend verification; DB-only stay RECORDED
- Honest capability reporting for LocalAI (unreachable → explicit fail, no silent wrong-model image gen)

### Preserved
- All V12 payment flows, port 5000 WebSSH/Admin, port 8787 webhooks
- Existing Discord commands and aliases
- Customer VPS records, orders, payments, port_forwards
- LXC provisioning path

### Not claimed / not tested on real host
- Public IPv4 end-to-end reachability
- Live SSH authentication against production VMs
- Provider-routed secondary public IPs without topology confirmation
