# SVM Advanced AI V13 — Operating System Support

**Made by AnkitCoder**

There are **two different “OS” questions**. Do not mix them.

| Role | Meaning | What SVM supports |
|------|---------|-------------------|
| **Host OS** | Machine where `bot.py` / `install.sh` / LXD-Incus run | Linux only (see below) |
| **Guest OS** | Image inside each customer VPS (LXC/Incus) | Any image that `!oshealth` verifies on *your* host |

Nothing is marked “sellable” until `lxc image info <alias>` (or equivalent) succeeds on the real host. Fake catalogs are not used.

---

## 1. Host OS (run the bot + installer)

### Fully targeted (apt-based)

| Distro | Installer packages | Notes |
|--------|-------------------|--------|
| **Ubuntu 24.04 LTS** | Full | Primary test target in V13 CI/sandbox |
| **Ubuntu 22.04 LTS** | Full | Production-common |
| **Ubuntu 20.04 LTS** | Full | Still supported |
| **Debian 12 (Bookworm)** | Full | |
| **Debian 11 (Bullseye)** | Full | |
| **Debian 13 (Trixie)** | Full (when stable packages exist) | |
| Linux Mint / Pop!_OS / Zorin / elementary / Kubuntu / Lubuntu / Xubuntu (Ubuntu-based) | Same as Ubuntu parent | Use Ubuntu instructions |
| Kali / Parrot (Debian-based) | apt path | Works if python3.9+ and LXD/Incus available |

### Best-effort (dnf/yum)

| Distro | Status |
|--------|--------|
| AlmaLinux 8/9/10 | Packages via dnf path in `install.sh` |
| Rocky Linux 8/9/10 | Same |
| CentOS Stream 8/9/10 | Same |
| Fedora / Fedora Server | Same |
| RHEL 8/9 / Oracle Linux 8/9 | Same (subscription/repos are your responsibility) |
| Amazon Linux 2023 / 2 | Best-effort; may need manual deps |

### Not a supported **host** for SVM bot

| Family | Why |
|--------|-----|
| **Windows** (10/11/Server/XP/…) | Bot is Linux systemd + LXC/Incus/libvirt; no Windows service path |
| **ReactOS, FreeDOS, MS-DOS, Haiku** | Not Linux |
| **FreeBSD / OpenBSD / NetBSD / DragonFly** | No LXD host path in this tree; installer is bash/apt/dnf |
| **OpenWrt, OPNsense, pfSense** | Router/firewall appliances — not VPS control-plane hosts |
| **TrueNAS CORE** (FreeBSD) | Not supported as bot host |
| **TrueNAS SCALE** | Debian-based — may run as host with manual work; **not** tested |
| **Proxmox VE** | Can host LXC; bot can run *on* a Proxmox node if you install deps, but Proxmox API is **not** integrated as a provider |
| **VMware ESXi / XCP-ng** | Hypervisor only — no Python bot runtime as ESXi VIB |
| **macOS, Solaris, illumos, Qubes, ChromeOS Flex** | Out of scope |
| **Android-x86 / Bliss / phones** | Out of scope |

`install.sh` uses `apt-get` or `dnf`/`yum`. Arch/Alpine/Gentoo/NixOS/Void as **host** need manual dependency install (not automated).

---

## 2. Guest OS (VPS images — LXC/Incus)

Default `OS_ALLOWLIST` (V13) includes common **images.linuxcontainers.org** aliases:

### Ubuntu
- Ubuntu 20.04 LTS — `ubuntu:20.04`
- Ubuntu 22.04 LTS — `ubuntu:22.04`
- Ubuntu 24.04 LTS — `ubuntu:24.04`

### Debian
- Debian 10 Buster — `images:debian/10`
- Debian 11 Bullseye — `images:debian/11`
- Debian 12 Bookworm — `images:debian/12`
- Debian 13 Trixie — `images:debian/13`

### RHEL-family
- AlmaLinux 8/9 — `images:almalinux/8`, `images:almalinux/9`
- Rocky Linux 8/9 — `images:rockylinux/8`, `images:rockylinux/9`
- CentOS Stream 9 — `images:centos/9-Stream`
- Oracle Linux 9 — `images:oracle/9`

### Other Linux guests
- Fedora 40/41 — `images:fedora/40`, `images:fedora/41`
- Alpine 3.20 — `images:alpine/3.20`
- Arch Linux — `images:archlinux`
- openSUSE Leap 15.6 — `images:opensuse/15.6`
- Kali current — `images:kali/current`

### Guest images that are **not** claimed

| Requested | Guest support in SVM V13 |
|-----------|---------------------------|
| Windows Server / Windows 10/11 | **No** (LXC is Linux containers; Windows needs KVM + licensed ISO — paid path is LXC only) |
| FreeBSD / OpenBSD as container | **No** standard LXC image path |
| Android, ChromeOS, ReactOS, DOS | **No** |
| macOS | **No** (licensing + hardware) |
| OpenWrt as VPS product | Possible only if you add a verified image alias yourself |

Add more guests anytime:

```bash
# In .env (comma-separated alias|Label)
OS_ALLOWLIST=ubuntu:22.04|Ubuntu 22.04 LTS,images:debian/12|Debian 12,...

# On Discord (admin)
!oshealth          # re-verify against local lxc/incus
!oslist            # show verified vs unavailable
```

Only **verified** rows appear in `!plans` / `!buy` OS pickers.

---

## 3. Virtualization layer

| Layer | Status in V13 |
|-------|----------------|
| **LXC / LXD / Incus** | Primary provisioning path for paid VPS |
| **KVM / QEMU / libvirt** | Detected + `!kvm-install`; **not** wired into paid auto-provision (same as V12) |
| Proxmox API | Not integrated |
| ESXi / XenCenter API | Not integrated |

---

## 4. ARM / Raspberry Pi

| Platform | Host | Guest |
|----------|------|-------|
| Ubuntu/Debian **ARM64** | Possible if python3.9+ and LXD/Incus exist | Use ARM images from the same remotes (`architectures` must match) |
| Raspberry Pi OS / DietPi / Armbian | Best-effort host | Guest only if image arch matches host |
| Arch Linux ARM | Manual host deps | Arch guest alias if published for that arch |

Always run `!oshealth` on the actual node — x86_64 images will show **unavailable** on ARM hosts.

---

## 5. Admin quick commands

```text
!oslist          All catalog rows + status
!oshealth        Re-check every allowlisted image on this host
!providerlist    LXC / KVM capability detection
!providerhealth  Live prerequisite check
```

---

## 6. Honesty summary

- **“All OS in your list” as host:** **No** — Windows/BSD/routers/ESXi are not bot hosts.
- **“All Linux guests in images remote”:** **Yes, if** the image exists on your node and passes verification.
- **Windows VPS product:** **Not** in V13 paid flow.
- Expanding the catalog only adds *candidates*; **verification** decides what customers can buy.

