# SVM V13 — Test Evidence Report

**Host under test (sandbox):** Ubuntu 24.04 · kernel 6.12.8+ · root  
**Host IPv4 observed:** `172.16.0.2/24` on `eth0`, default via `172.16.0.1`  
**ip_forward:** `0` (dry-run only unless `--apply-network`)  
**Firewall backend detected:** `nftables` (iptables-nft compatibility used for rule apply)

## Command

```bash
python3 -m pytest tests/test_ipam_v13.py tests/test_ssh_net_v13.py tests/test_integration_v13_live.py -v
```

## Result

**41 passed in 6.75s** · exit code 0

### Breakdown

| Area | Result | Evidence |
|------|--------|----------|
| CIDR / overlap / CGNAT heuristic | **PASS** | unit |
| Concurrent IPAM no duplicate IPs | **PASS** | 8 workers, unique addresses |
| IPAM lifecycle → ACTIVE + health=verified | **PASS** | SQLite file |
| iptables dry-run | **PASS** | |
| **iptables live apply + SVM comment + cleanup** | **PASS** | `Applied 2 rules`, `OWNED_MATCH 2`, cleaned |
| NAT reject unowned public IP | **PASS** | 203.0.113.50 refused |
| Address ownership (127.0.0.1 yes / 8.8.8.8 no) | **PASS** | |
| Network diagnostic snapshot | **PASS** | backend=nftables, addrs listed |
| SSH TCP probe closed port | **PASS** | refused |
| SSH connection_profile Termius/OpenSSH | **PASS** | |
| LocalAI mock `/v1/models` | **PASS** | |
| LocalAI mock chat completion | **PASS** | |
| **LocalAI mock image generation → valid PNG** | **PASS** | magic `\x89PNG` |
| LocalAI unreachable fails cleanly | **PASS** | |
| bot.py AST + single active `vpsinfo` | **PASS** | |
| Module compile (ipam/net/ssh/svm12) | **PASS** | |

### Live apply evidence (excerpt)

```
APPLY True Applied 2 rules
OWNED_MATCH 2
CLEANED True
backend nftables modes ['record', 'portfwd', 'nat']
```

## Still BLOCKED on this sandbox (need your VPS)

| Item | Why blocked | How you verify on real host |
|------|-------------|------------------------------|
| Provider **public** IPv4 ownership | This host only has RFC1918 `172.16.0.2` | `ip -j addr`; compare panel IP |
| **External** inbound NAT from internet | No public route into this sandbox | From phone/laptop: `nc -vz YOUR_PUBLIC_IP PORT` |
| Real **SSH authentication** to customer VPS | No sshd / no customer keys here | `!sshfix <vps>` after install; Termius login |
| Real **LocalAI** GPU models | Nothing listening on `:8080` here | Start LocalAI; `!askai models`; `!askai image …` |
| Installer writing `/opt/svm` | Sandbox FS quirks for venv lib64 | `sudo bash install.sh upgrade` on VPS |

## Your VPS checklist (copy-paste)

```bash
# 1. Upgrade
cd SVM-Advanced-V13 && sudo bash install.sh upgrade

# 2. Doctor
sudo bash install.sh doctor
svm doctor

# 3. Tests on server
sudo bash install.sh test
# or:
cd /opt/svm && ./venv/bin/python -m pytest tests/test_ipam_v13.py tests/test_integration_v13_live.py -q

# 4. Network
ip -j addr; ip -j route; cat /proc/sys/net/ipv4/ip_forward
sudo iptables-save | grep SVM-V13 || true

# 5. LocalAI
curl -sS http://127.0.0.1:8080/v1/models | head
# Discord: !askai models   !askai image a red cube

# 6. SSH
# Discord: !sshfix <vps>
# Termius: use profile from bot (host/port/user — no password in chat)
```

## Honesty rule (unchanged)

- Mapping **ACTIVE** only after host rules applied + verified  
- DB-only = **RECORDED**  
- Public connectivity **VERIFIED** only after external check  
- SSH_AUTHENTICATED only after real login test  
