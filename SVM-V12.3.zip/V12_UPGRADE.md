# SVM+ V12 upgrade - audit, changes, setup, test report
Made by AnkitCoder. Additive upgrade of the existing project: nothing was replaced, every legacy command name/alias still exists (checked against a 100-name snapshot).

## 1. Audit result (what was really there)
- **Entry point:** `bot.py` (single file, layers V11.2 -> SVM+ 11.3-PLUS -> AI layer), `bot.run()` last. Service `svm`, dir `/opt/svm`, SQLite `vps.db`, WebSSH/Admin on :5000, payment webhook server on :8787, provider = LXC/LXD via the `lxc` CLI.
- **Journey:** `!plans` -> `!buy` -> `v112v_orders` -> signed webhook (Razorpay/Stripe) or manual UPI -> `v112v_auto_provision_order` -> LXC VPS -> DM -> `svm_billing`.
- **Defects found and fixed in V12**
| # | Defect | Fix |
|---|---|---|
|1|UPI `approve-order` marked an order paid with a synthetic reference - no bank reference, no amount check, no reviewer record|`!approvepayment <order> <bank_ref> <amount>`: exact amount, unique reference registry, reviewer != buyer, reviewer row; old names kept as aliases|
|2|Payment proof trusted the client MIME type, stored `.bin`, no OCR, no duplicate detection|magic-byte validation (PNG/JPEG/WEBP/GIF), size + dimension/decompression-bomb limits, `0600` files in a `0700` dir, SHA-256 + reference reuse detection, optional OCR, retention purge|
|3|No `fulfilling` state: retry vs webhook had a small double-VPS window; legacy handler provisioned on every event (authorized + captured = 2 VPS)|atomic `paid -> fulfilling -> provisioned` claim; legacy handler delegates to the exactly-once one; restart recovery|
|4|Raw webhook JSON (payer e-mail, phone, VPA) stored in DB|redacted before storage; result recorded per event|
|5|Webhook had no socket timeout, no optional merchant-account pin|15 s timeout, `RAZORPAY_ACCOUNT_ID` pin|
|6|OS fixed by env, never verified; no account/quota/capacity check before charging|verified OS catalog + OS selection menu, account/quota/capacity/OS pre-check **before** an order is created|
|7|`!kvm-install` installed host packages with no confirmation|requires `!kvm-install confirm`, states what it will/won't do|
|8|Installer never deployed `admin.html`; `ast.parse` validation missed symbol errors|fixed earlier + `compile()` validation + migration dry-run on a copy|

## 2. Files
New: `svm12.py` (core, no Discord dependency), `tests/` (unit + integration), `V12_UPGRADE.md`.
Changed: `bot.py` (additive V12 block + targeted fixes), `install.sh`, `.env.example`, `requirements.txt`, `CHANGELOG.md`.

## 3. Database migrations (additive, versioned, `svm_schema_migrations`)
12001 accounts - 12002 order options/fulfilment columns - 12003 proof evidence columns - 12004 reviews + reference registry - 12005 invoices + refunds - 12006 OS catalog, settings, webhook result - 12007 indexes.
A consistent backup is written to `db_backups/pre-v12-*.db` before the first migration. Rollback = `svm rollback` (code) + restore that DB copy if you must undo (new columns/tables are harmless to old code).

## 4. Payment gateways
- **Razorpay** (existing Payment-Links flow, kept): `.env` `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, `RAZORPAY_WEBHOOK_SECRET`, optional `RAZORPAY_ACCOUNT_ID`. Dashboard -> Webhooks -> URL `https://YOUR-DOMAIN/razorpay/webhook`, events `payment_link.paid` and `payment.captured`, same secret. Amounts are integer paise, INR. Provisioning needs: valid HMAC over the **raw body** + a live Razorpay API lookup showing the same amount, INR and status `captured` (`payment.authorized` is ignored unless `RAZORPAY_ACCEPT_AUTHORIZED=true`). Browser redirects and button clicks never count.
- **Stripe**: unchanged. **Cashfree/PayU: not implemented** (no credentials/API access to build and verify against).
- **HTTPS:** keep `PAYMENT_WEBHOOK_HOST=127.0.0.1` and put a TLS reverse proxy in front, e.g. nginx `location /razorpay/webhook { proxy_pass http://127.0.0.1:8787; client_max_body_size 1m; }` and set `SVM_PUBLIC_URL`.
- State map: `created` (CREATED/PENDING) -> `paid` (VERIFIED) -> `fulfilling` -> `provisioned`/`renewed` (FULFILLED); `review_required`, `expired`, `cancelled`, `rejected`, `refunded`; failed provisioning returns to `paid` (retryable, payment preserved).

## 5. UPI + independent verification
`!setupi merchant@bank "Display Name"` (or `UPI_ID`/`UPI_NAME`). The id is **a string, not a verified merchant** - send yourself a test payment first.
Buyer flow: pay -> DM the bot `!submitproof <order>` + screenshot -> order becomes `review_required` -> staff alert shows OCR fields **with flags** (amount/payee/date/reference/status mismatches, reused screenshot/reference).
Reviewer flow: open your bank/UPI app, find the credit, then `!approvepayment <order> <UTR from your statement> <amount you saw> [note]`. The system refuses a wrong amount, a short reference, a reference already used on another order, and the buyer approving their own order. `!rejectpayment <order> <reason>`. A screenshot alone can never activate an order; OCR is evidence only.

## 6. OS catalog and virtualization
- `OS_ALLOWLIST` (`alias|Label,...`, default Ubuntu 22.04/24.04, Debian 12). `!oshealth` runs `lxc image info <alias>` for each; only **verified** images appear in `!oslist`/`!plans`/the `!buy` menu and are sellable. The chosen OS is re-verified at provisioning and **never silently replaced** (order stays `paid` for retry if it vanished). On a host without a local `lxc` CLI (remote nodes only) set `OS_VERIFY_STRICT=false`.
- `!providerlist` / `!providerhealth`: real detection (`/dev/kvm` rw, qemu, qemu-img, virsh/libvirt daemon, virt-install, seed tool, pool, network; incus/lxc daemon, pools, networks).
- **KVM/QEMU is detected and reported, and `svm12.KvmProvider` (libvirt/virt-install/cloud-init, argv-only, refuses unless every prerequisite passes) exists - but paid orders are provisioned on LXC only.** Wiring KVM into the paid flow was deliberately not enabled because it cannot be verified without a KVM host. `!kvm-install confirm` (main admin) installs packages; it never reboots or touches bridges/firewall/network.

## 7. Safe upgrade / backup / rollback
```bash
cd SVM-Advanced-AI
sudo bash install.sh                 # backup -> deploy bot.py + svm12.py -> validate (compile + migration dry-run on a COPY) -> restart
sudo bash install.sh --with-ocr      # optional: tesseract-ocr + pytesseract
svm doctor                           # service, gateways, db migration version, OCR, /dev/kvm, lxc/incus
svm test                             # run the test-suite on the server
svm backup ; svm rollback            # snapshot / restore bot.py+svm12.py (+ prints the DB snapshot path)
python3 /opt/svm/svm12.py migrate-check /opt/svm/vps.db   # dry-run on a copy, never touches the real DB
```
`.env` is never overwritten. Interrupted provisioning after a crash is detected at start (`paid` again + admin alert).

## 8. Commands added
User: `!account` `!balance` (no wallet exists - shows what is active/owed) `!orders` `!billing` `!payments` `!paymentstatus` `!submitproof` `!invoice` `!refundrequest` `!vpsinfo` `!startvps` `!stopvps` `!restartvps` `!oslist` `!providerlist` `!botinfo` (and the redesigned `!plans`/`!buy` menu).
Admin: `!adminpayments` `!approvepayment` `!rejectpayment` `!viewproof` `!refund-mark` `!setupi` `!setgateway` `!setprice` `!setplan` `!providerhealth` `!oshealth` `!provisioningjobs` `!auditlogs` `!billingreport` `!vpsadmin`.
`!orders`/`!billing` keep their admin views for admins and show your own records to everyone else. Billing details go to DMs. Slash commands: **not implemented** (the bot is prefix-based).

## 9. `!botinfo`
Shows real version (bot, SVM+ core, V12), latency/uptime, Python/discord.py, detected providers, verified-OS count, configured gateways + webhook up/down, plans, counts from the bot's own records. Image: the project's existing `BOT_THUMBNAIL_URL` + the live bot avatar; optional `BOT_BANNER_URL` (https), `SUPPORT_SERVER_URL`, `DOCS_URL`. It never claims to have changed the Discord profile.

## 10. Example journeys
**Purchase:** `!plans` -> `!buy starter` -> pick OS + payment -> Continue -> pay link/UPI details by DM -> (Razorpay) signed webhook verified -> `fulfilling` -> VPS created -> DM with access -> `!paymentstatus 42`, `!invoice 42`.
**Admin review:** user DMs proof -> alert in admin channel (flags) -> admin checks bank -> `!approvepayment 42 412345678901 499.00 "HDFC credit 10:32"` -> fulfilment starts; or `!rejectpayment 42 no credit found`.
**Paid but provisioning fails:** order stays `paid` (payment preserved), admins alerted -> fix cause -> `!retry-payment 42` (no second charge) -> `provisioned`. Refund path: `!refundrequest 42 reason` -> admin issues it in the gateway dashboard -> `!refund-mark <id> refunded`.

## 11. Test report  (`python3 -m unittest discover -s tests -v`: 53 tests, all pass in the build sandbox)
| # | Area | Result |
|---|---|---|
|1|DB creation + upgrade migrations|**PASS** fresh DB, legacy-schema upgrade with data preserved, idempotent re-run, pre-migration backup, CLI dry-run leaves real DB untouched, corrupt DB rejected|
|2|Duplicate webhook|**PASS** same event id, retry with new event id, 12 concurrent deliveries -> one fulfilment|
|3|Invalid signature|**PASS** missing / wrong secret -> 401, order untouched|
|4|Wrong amount/currency|**PASS** (mocked Razorpay API) amount, USD, `authorized`, `failed` all rejected|
|5|OCR without false approval|**PASS** real Tesseract OCR on a generated image; order only reaches `review_required`; nothing scheduled|
|6|Manual review permissions|**PASS** logic (wrong amount, short ref, self-approval, gateway order, double approve); every admin command has `@is_admin()` (source-checked). Enforcement by real discord.py: **NOT TESTED**|
|7|Duplicate UTR/reference|**PASS** registry uniqueness + proof-level reuse flags|
|8|Exactly-once + retries|**PASS** 6 parallel workers -> 1 VPS; re-run -> still 1; restart recovery|
|9|Payment ok, provisioning fails|**PASS** order stays `paid`, retry succeeds, no 2nd VPS (provisioner mocked; real LXC **NOT TESTED**)|
|10|Ownership/admin auth|**PASS** proofs, refunds, `!vpsinfo`/power commands (stranger denied, admin allowed)|
|11|Pricing/quota|**PASS** quota, capacity, suspended account, INR parsing|
|12|OS availability / invalid alias|**PASS** (mocked image source) unavailable alias hidden, not sellable, re-checked at provisioning|
|13|KVM detection|**PASS** mocked; real here: not ready (no /dev/kvm, qemu, libvirt) - **real KVM host: BLOCKED**|
|14|LXC/Incus detection|**PASS** mocked; real here: no lxc - **real LXD host: BLOCKED**|
|15|Provider lifecycle|**PASS** mocked runner (argv-only, name validation, refuses when unavailable); real VM/container creation **BLOCKED**|
|16|Command compatibility|**PASS** all 100 legacy names/aliases present; new commands listed in `!help`|
|17|Installer backup/rollback|**PASS** in a sandbox: snapshot contents, validation rejects broken svm12.py, rollback restores; full install on a real Ubuntu host with systemd/apt/git: **NOT TESTED**|
|18|Secrets not in logs|**PASS** webhook paths (secret, key ids, admin password, payer e-mail)|
|19|Malicious uploads|**PASS** exe, ELF, script, zip, PDF, SVG, PHP, disguised/truncated PNG, bomb dimensions, oversize|
|20|Discord interaction handling|**NOT TESTED** against real discord.py (stubs only): `!buy` menu, buttons, selects|
Also **BLOCKED**: live Razorpay/Stripe API calls (no credentials/network), real Discord gateway, real payments.

## 12. Known limitations (honest)
- No recurring auto-charge/subscriptions (renewal = a new paid order); no upgrade/downgrade flow; no Cashfree/PayU; no slash commands.
- KVM not sold automatically (see section 6). Instance snapshots/reinstall/delete flows are the pre-existing ones and were not re-audited.
- Razorpay uses the existing Payment-Links flow (webhook-verified); client-side checkout-signature verification is not applicable to it.
- `!balance` is not a wallet. Storage/disk-space capacity is checked per node VPS-slot, not per GB.
- Pre-existing: VPS root and panel passwords are kept in the bot's data as before (DM'd once); not changed to avoid breaking existing instances.
- Do not call this production-ready until you have run, on the real host: a real Razorpay test-mode payment end to end, `svm doctor`, `svm test`, and one manual-UPI approval.
