# SVM Advanced AI V13 — Upgrade Guide

**Made by AnkitCoder**

## What changed in V13

| Area | V12 | V13 |
|------|-----|-----|
| IPAM lifecycle | available / allocated / reserved | available, reserved, assigned, configuring, **active**, failed, releasing, quarantined |
| Mapping health | implicit | RECORDED / INSTALLED / VERIFIED / DRIFT / FAILED |
| NAT backend | iptables only | Capability detection; iptables with owned comments |
| ACTIVE claim | DB status | Only after backend apply + verify |
| SSH states | informal | SERVICE_RUNNING → PORT_LISTENING → TCP_REACHABLE → BANNER_OK → AUTHENTICATED |
| Termius profile | ad-hoc | connection_profile() returns copyable Host/Port/User snippet |
| Modules | monolithic bot.py | svm_ipam.py, svm_net.py, svm_ssh.py + existing bot/svm12 |
| Installer | install / rollback | + upgrade, backup, test, doctor, env merge, pre-v13 backups |
| Version | 11.2 / 12.0 mixed | **13.0** consistent |

## Supported network topologies

1. **record** — DB bookkeeping only. Never reported as publicly reachable.
2. **portfwd** — Host public IPv4 + TCP/UDP DNAT to private VM port.
3. **nat** (1:1) — DNAT+SNAT for a dedicated public IP on the host interface.
4. **routed** — Provider routes public IP to host; automatic programming rejected until topology confirmed.
5. **bridged** — Legacy LXD static address (unchanged).

Provider panels (e.g. single IPv4 with gateway 10.0.0.1 / 255.255.255.255) often mean hypervisor NAT. V13 detects missing address ownership and will not claim 1:1 NAT success.

## Upgrade path (V12 → V13)

```bash
cd /path/to/SVM-Advanced-V13
sudo bash install.sh upgrade
# or:
sudo bash install.sh
```

Installer actions:
1. Detect /opt/svm, service svm, vps.db, .env
2. Timestamped backups: db_backups/pre-v13-*.db, .env.bak-v13-*, backups/pre-v13-*/
3. Never overwrite live .env values; append missing keys only
4. Deploy bot.py, svm12.py, svm_ipam.py, svm_net.py, svm_ssh.py
5. compileall / AST validation
6. Additive migration 13001
7. Restart service

### Rollback

```bash
sudo bash install.sh rollback
sudo systemctl stop svm
sudo cp /opt/svm/db_backups/pre-v13-….db /opt/svm/vps.db
sudo systemctl start svm
```

## Doctor and tests

```bash
sudo bash install.sh doctor
sudo bash install.sh test
svm doctor
svm test
```

## IPAM notes

- Commands: !ipool list|add|alloc|release|reserve|detail|free|find|nat|sync
- ACTIVE only when status=active and health in {installed, verified}
- DB-only rows remain RECORDED
- Reconciliation is idempotent

## SSH / Termius

- Default user root, port 22 only when permitted
- Structured states; authentication never fabricated
- connection_profile() for Termius / OpenSSH (no secrets)

## LocalAI

- Unreachable endpoint → clear error, task cancelled safely
- AI_IMAGE_ENABLED=false by default
- SVG sanitization separate from raster generation

## Limitations (honest)

- Real-host public connectivity and SSH authentication are NOT TESTED in the build environment
- nftables full management is detected; apply path uses iptables with owned comments when selected
- Routed public IP auto-programming disabled without topology confirmation
- KVM paid provisioning remains detection-only (same as V12)
