SVM MOTD — based on github.com/Ankitcoder42-collab/Svm-motd (Svm.sh), hardened:
- no pam_exec hook (it printed into scp/sftp/WebSSH exec sessions), shown on interactive terminals only, once per login
- sshd: PrintMotd no + UseDNS no (avoids slow "protocol banner" on login)
- IPv4 list, real CPU % from /proc/stat, idempotent, safe sshd reload
