#!/bin/bash
# ==========================================
# SVM v11.2 AI System Premium MOTD Installer
# Based on github.com/Ankitcoder42-collab/Svm-motd (Svm.sh)
# Hardened: no pam_exec (it broke WebSSH / scp / sftp), interactive-only,
# idempotent, works in LXC / KVM / bare metal, IPv4 aware.
# (shipped locally with the bot — nothing is downloaded)
# ==========================================

echo "🔧 Installing SVM v11.2 AI System Premium MOTD..."

mkdir -p /etc/update-motd.d /etc/profile.d

# ---- remove the old MOTD system (same as original Svm.sh) ----
echo "🧹 Removing old MOTD completely..."
chmod -x /etc/update-motd.d/* 2>/dev/null || true
rm -f /etc/motd /var/run/motd /run/motd.dynamic
[ -f /etc/default/motd-news ] && sed -i 's/ENABLED=1/ENABLED=0/g' /etc/default/motd-news

# ---- clean old pam_exec hook from earlier installs (it printed MOTD into non-interactive sessions) ----
for f in /etc/pam.d/sshd /etc/pam.d/login; do
    [ -f "$f" ] || continue
    sed -i '\|00-svm-ai-system|d' "$f" 2>/dev/null || true
    sed -i '/pam_motd.so/d' "$f" 2>/dev/null || true       # stock Ubuntu/Debian MOTD off -> only SVM shows
done

# ---- sshd: no double MOTD, no slow DNS reverse lookup (avoids 'Error reading SSH protocol banner') ----
if [ -f /etc/ssh/sshd_config ]; then
    mkdir -p /etc/ssh/sshd_config.d 2>/dev/null || true
    if grep -qE '^[[:space:]]*Include[[:space:]]+/etc/ssh/sshd_config.d' /etc/ssh/sshd_config 2>/dev/null; then
        printf 'PrintMotd no\nUseDNS no\nPrintLastLog no\n' > /etc/ssh/sshd_config.d/00-svm.conf
    else
        sed -i -E 's/^[#[:space:]]*PrintMotd.*/PrintMotd no/; s/^[#[:space:]]*UseDNS.*/UseDNS no/' /etc/ssh/sshd_config
        grep -qE '^PrintMotd' /etc/ssh/sshd_config || echo 'PrintMotd no' >> /etc/ssh/sshd_config
        grep -qE '^UseDNS' /etc/ssh/sshd_config   || echo 'UseDNS no'   >> /etc/ssh/sshd_config
    fi
fi

# ---- the MOTD itself ----
echo "✨ Creating SVM v11.2 AI System MOTD..."
cat << 'SVM_MOTD_EOF' > /etc/update-motd.d/00-svm-ai-system
#!/bin/bash
# SVM v11.2 AI System MOTD — shown only on interactive terminals
[ -t 1 ] || exit 0

# ===== Colors =====
GREEN="\e[38;5;82m"
CYAN="\e[38;5;51m"
BLUE="\e[38;5;39m"
MAGENTA="\e[38;5;213m"
YELLOW="\e[38;5;220m"
RED="\e[38;5;196m"
GRAY="\e[38;5;245m"
WHITE="\e[97m"
RESET="\e[0m"

# ===== System Information =====

HOSTNAME=$(hostname)

OS=$(grep PRETTY_NAME /etc/os-release 2>/dev/null |
     cut -d= -f2 | tr -d '"')

KERNEL=$(uname -r)

UPTIME=$(uptime -p 2>/dev/null | sed 's/up //')
UPTIME=${UPTIME:-Unknown}

# CPU
CPU="N/A"
if [ -r /proc/stat ]; then
    read -r _ u1 n1 s1 i1 w1 q1 sq1 _ < /proc/stat
    sleep 0.2
    read -r _ u2 n2 s2 i2 w2 q2 sq2 _ < /proc/stat
    t1=$((u1+n1+s1+i1+w1+q1+sq1)); t2=$((u2+n2+s2+i2+w2+q2+sq2))
    dt=$((t2-t1)); di=$(((i2+w2)-(i1+w1)))
    [ "$dt" -gt 0 ] && CPU="$(( (100*(dt-di))/dt ))%"
fi

# Memory
MEM_TOTAL=$(free -m 2>/dev/null | awk '/Mem:/ {print $2}')
MEM_USED=$(free -m 2>/dev/null | awk '/Mem:/ {print $3}')

MEM_TOTAL=${MEM_TOTAL:-0}; MEM_USED=${MEM_USED:-0}
if [ "$MEM_TOTAL" -gt 0 ] 2>/dev/null; then
    MEM_PERC=$((MEM_USED * 100 / MEM_TOTAL))
else
    MEM_PERC=0
fi

# Disk
DISK=$(df -h / 2>/dev/null |
       awk 'NR==2 {print $3 " / " $2 " (" $5 ")"}' ||
       echo "N/A")

# IP
# IPv4 only (works in LXC / KVM / bare metal)
IP=$(ip -4 -o addr show scope global 2>/dev/null | awk '{print $4}' | cut -d/ -f1 | paste -sd' ' -)
[ -z "$IP" ] && IP=$(hostname -I 2>/dev/null | tr ' ' '\n' | grep -E '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$' | paste -sd' ' -)
IP=${IP:-N/A}

# Users
USERS=$(who 2>/dev/null | wc -l)

# Processes
PROCS=$(ps -e --no-headers 2>/dev/null | wc -l)

echo ""

# ==========================================
# SVM v11.2 AI SYSTEM LOGO
# ==========================================

echo -e "${MAGENTA}"

cat << "LOGO"

 ███████╗██╗   ██╗███╗   ███╗
 ██╔════╝██║   ██║████╗ ████║
 ███████╗██║   ██║██╔████╔██║
 ╚════██║╚██╗ ██╔╝██║╚██╔╝██║
 ███████║ ╚████╔╝ ██║ ╚═╝ ██║
 ╚══════╝  ╚═══╝  ╚═╝     ╚═╝

 ██████╗ ██╗ ██╗
 ██╔══██╗██║███║
 ██║  ██║██║╚██║
 ██║  ██║██║ ██║
 ██████╔╝██║ ██║
 ╚═════╝ ╚═╝ ╚═╝

        v11.2 AI SYSTEM

LOGO

echo -e "${RESET}"

# ==========================================
# HEADER
# ==========================================

echo -e "${GREEN}🤖 Welcome to SVM v11.2 AI System${RESET}"
echo -e "${BLUE}Advanced AI • High Performance • Secure Infrastructure${RESET}"
echo -e "${GRAY}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"

# ==========================================
# SYSTEM STATUS
# ==========================================

printf "${CYAN}%-18s${RESET} %s\n" "Hostname:" "$HOSTNAME"
printf "${CYAN}%-18s${RESET} %s\n" "OS:" "$OS"
printf "${CYAN}%-18s${RESET} %s\n" "Kernel:" "$KERNEL"
printf "${CYAN}%-18s${RESET} %s\n" "Uptime:" "$UPTIME"
printf "${CYAN}%-18s${RESET} %s\n" "CPU Usage:" "$CPU"

printf "${CYAN}%-18s${RESET} %sMB / %sMB (${YELLOW}%s%%${RESET})\n" \
"Memory:" "$MEM_USED" "$MEM_TOTAL" "$MEM_PERC"

printf "${CYAN}%-18s${RESET} %s\n" "Disk:" "$DISK"
printf "${CYAN}%-18s${RESET} %s\n" "Processes:" "$PROCS"
printf "${CYAN}%-18s${RESET} %s\n" "Users:" "$USERS"
printf "${CYAN}%-18s${RESET} %s\n" "IP:" "$IP"

echo -e "${GRAY}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"

# ==========================================
# SVM SERVICES
# ==========================================

echo -e "${GREEN}⚡ SVM System:${RESET}  ${WHITE}v11.2 AI${RESET}"
echo -e "${GREEN}🧠 AI Engine:${RESET}    ${WHITE}Online${RESET}"
echo -e "${GREEN}🔐 Security:${RESET}     ${WHITE}Active${RESET}"
echo -e "${GREEN}🖥️  WebSSH:${RESET}       ${WHITE}Available${RESET}"

echo -e "${GRAY}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"

# ==========================================
# SUPPORT
# ==========================================

echo -e "${GREEN}Support:${RESET}  SVM Support"
echo -e "${GREEN}Discord:${RESET}  SVM Discord"
echo -e "${GREEN}WebSSH:${RESET}   WebSSH"

echo -e "${MAGENTA}SVM v11.2 AI System — Advanced Server Infrastructure 🤖${RESET}"

echo ""

SVM_MOTD_EOF
chmod +x /etc/update-motd.d/00-svm-ai-system

# ---- show it on every interactive login shell (SSH, WebSSH, console) exactly once ----
cat << 'SVM_PROFILE_EOF' > /etc/profile.d/00-svm-motd.sh
# SVM MOTD — interactive login shells only, once per session
case "$-" in *i*) ;; *) return 0 2>/dev/null || exit 0 ;; esac
[ -t 1 ] || return 0 2>/dev/null
if [ -z "$SVM_MOTD_SHOWN" ] && [ -x /etc/update-motd.d/00-svm-ai-system ]; then
    export SVM_MOTD_SHOWN=1
    /etc/update-motd.d/00-svm-ai-system
fi
SVM_PROFILE_EOF
chmod 644 /etc/profile.d/00-svm-motd.sh

# bash non-login interactive shells (some terminals) -> source it too
if [ -f /etc/bash.bashrc ] && ! grep -q '00-svm-motd.sh' /etc/bash.bashrc; then
    echo '[ -r /etc/profile.d/00-svm-motd.sh ] && . /etc/profile.d/00-svm-motd.sh' >> /etc/bash.bashrc
fi

# ---- apply sshd settings safely (only if config is valid) ----
if command -v sshd >/dev/null 2>&1 && sshd -t 2>/dev/null; then
    systemctl reload ssh 2>/dev/null || systemctl reload sshd 2>/dev/null || \
    systemctl restart ssh 2>/dev/null || systemctl restart sshd 2>/dev/null || true
fi

echo ""
echo "✅ SVM v11.2 AI System MOTD Installed"
echo "🚫 All default MOTD disabled"
echo "🤖 Only SVM v11.2 AI MOTD will show"
echo "➡ Reconnect SSH / WebSSH to see changes"
exit 0
