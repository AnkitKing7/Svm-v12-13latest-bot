"""SVM+ V13 core  -  Made by AnkitCoder.

Pure-Python helpers with NO Discord dependency so every rule can be unit-tested:

  * versioned, additive SQLite migrations (+ automatic pre-migration backup)
  * payment-proof validation (magic bytes, size, dimensions), optional OCR, field extraction
  * proof-vs-order comparison  (OCR is *evidence only*: it can never mark an order paid)
  * manual UPI review workflow  (REVIEW_REQUIRED -> approve/reject with reviewer, reference, amount)
  * accounts, invoices, refund requests
  * event redaction for webhook payloads
  * provider capability detection + provider classes (LXC/Incus/LXD, KVM/QEMU via libvirt)
  * OS image catalog verification

Payment states used by the project (lower-case in v112v_orders.status):
  created (CREATED/PENDING)  -> paid (VERIFIED) -> fulfilling -> provisioned | renewed (FULFILLED)
  review_required (manual UPI proof waiting for an authorised reviewer)
  failed-provisioning orders go back to `paid` (retryable)  |  expired | cancelled | rejected
  refund_pending | refunded  (tracked in svm_refunds; refunds themselves are issued in the gateway dashboard)
"""
from __future__ import annotations

import hashlib
import io
import json
import os
import re
import shutil
import sqlite3
import struct
import subprocess
import time
from datetime import datetime, timedelta
from decimal import Decimal, InvalidOperation

V12_VERSION = "12.0"
V13_VERSION = "13.0"
SVM12_VERSION = V13_VERSION  # alias for botinfo

# --------------------------------------------------------------------------- states
ORDER_OPEN_STATES = ("created", "expired", "review_required")
ORDER_TERMINAL_STATES = ("provisioned", "renewed", "cancelled", "rejected", "refunded")
ALL_ORDER_STATES = ("created", "paid", "fulfilling", "provisioned", "renewed", "review_required",
                    "expired", "cancelled", "rejected", "refund_pending", "refunded")


def now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds")


# --------------------------------------------------------------------------- migrations
def _table_exists(conn, table):
    return conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone() is not None


def _add_column(conn, table, column, ddl):
    if not _table_exists(conn, table):
        return
    cols = {r[1] for r in conn.execute(f"PRAGMA table_info({table})").fetchall()}
    if column not in cols:
        conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {ddl}")


def _m_accounts(conn):
    conn.execute("""CREATE TABLE IF NOT EXISTS svm_accounts(
        id INTEGER PRIMARY KEY AUTOINCREMENT, discord_id TEXT NOT NULL UNIQUE, display_name TEXT DEFAULT '',
        status TEXT NOT NULL DEFAULT 'active', suspended_reason TEXT DEFAULT '', profile_json TEXT DEFAULT '{}',
        created_at TEXT NOT NULL, updated_at TEXT NOT NULL)""")


def _m_order_columns(conn):
    for col, ddl in (("os_image", "TEXT"), ("virt_provider", "TEXT DEFAULT 'lxc'"),
                     ("review_note", "TEXT DEFAULT ''"), ("fulfilled_at", "TEXT"), ("fulfilling_since", "TEXT")):
        _add_column(conn, "v112v_orders", col, ddl)


def _m_proof_columns(conn):
    for col, ddl in (("mime", "TEXT DEFAULT ''"), ("size", "INTEGER DEFAULT 0"), ("width", "INTEGER DEFAULT 0"),
                     ("height", "INTEGER DEFAULT 0"), ("path", "TEXT DEFAULT ''"), ("ocr_status", "TEXT DEFAULT 'not_run'"),
                     ("ocr_amount_paise", "INTEGER"), ("ocr_utr", "TEXT DEFAULT ''"), ("ocr_date", "TEXT DEFAULT ''"),
                     ("ocr_payment_status", "TEXT DEFAULT ''"), ("ocr_confidence", "REAL"), ("flags", "TEXT DEFAULT ''"),
                     ("purge_after", "TEXT"), ("deleted_at", "TEXT")):
        _add_column(conn, "v112v_payment_proofs", col, ddl)


def _m_reviews(conn):
    conn.execute("""CREATE TABLE IF NOT EXISTS svm_payment_reviews(
        id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER NOT NULL, reviewer_id TEXT NOT NULL,
        decision TEXT NOT NULL, bank_reference TEXT DEFAULT '', amount_paise INTEGER, reason TEXT DEFAULT '',
        created_at TEXT NOT NULL)""")
    conn.execute("""CREATE TABLE IF NOT EXISTS svm_utr_registry(
        utr TEXT PRIMARY KEY, order_id INTEGER NOT NULL, source TEXT NOT NULL, created_at TEXT NOT NULL)""")


def _m_invoices_refunds(conn):
    conn.execute("""CREATE TABLE IF NOT EXISTS svm_invoices(
        id INTEGER PRIMARY KEY AUTOINCREMENT, invoice_no TEXT NOT NULL UNIQUE, order_id INTEGER NOT NULL UNIQUE,
        user_id TEXT NOT NULL, plan_slug TEXT, kind TEXT, amount_paise INTEGER NOT NULL,
        currency TEXT NOT NULL DEFAULT 'INR', provider TEXT, created_at TEXT NOT NULL)""")
    conn.execute("""CREATE TABLE IF NOT EXISTS svm_refunds(
        id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER NOT NULL, user_id TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'requested', reason TEXT DEFAULT '', requested_by TEXT, decided_by TEXT,
        decision_note TEXT DEFAULT '', created_at TEXT NOT NULL, updated_at TEXT NOT NULL)""")


def _m_os_and_events(conn):
    conn.execute("""CREATE TABLE IF NOT EXISTS svm_os_images(
        alias TEXT PRIMARY KEY, label TEXT NOT NULL, provider TEXT NOT NULL DEFAULT 'lxc', arch TEXT DEFAULT '',
        status TEXT NOT NULL DEFAULT 'unknown', detail TEXT DEFAULT '', checked_at TEXT)""")
    conn.execute("""CREATE TABLE IF NOT EXISTS svm_settings(key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_at TEXT NOT NULL)""")
    _add_column(conn, "svm_webhook_events", "result", "TEXT DEFAULT ''")


def _m_indexes(conn):
    for name, table, cols in (("ix_v12_orders_user_status", "v112v_orders", "user_id,status"),
                              ("ix_v12_proofs_sha", "v112v_payment_proofs", "sha256"),
                              ("ix_v12_proofs_order", "v112v_payment_proofs", "order_id"),
                              ("ix_v12_billing_user", "svm_billing", "user_id"),
                              ("ix_v12_reviews_order", "svm_payment_reviews", "order_id"),
                              ("ix_v12_refunds_order", "svm_refunds", "order_id")):
        if _table_exists(conn, table):
            conn.execute(f"CREATE INDEX IF NOT EXISTS {name} ON {table}({cols})")


MIGRATIONS = (
    (12001, "accounts", _m_accounts),
    (12002, "order options + fulfilment columns", _m_order_columns),
    (12003, "payment proof evidence columns", _m_proof_columns),
    (12004, "manual payment reviews + reference registry", _m_reviews),
    (12005, "invoices + refund requests", _m_invoices_refunds),
    (12006, "os image catalog, settings, webhook result", _m_os_and_events),
    (12007, "indexes", _m_indexes),
)


def backup_database(db_file, backup_dir=None, tag="pre-v12"):
    """Consistent online copy (sqlite backup API). Returns the backup path or None."""
    if not db_file or not os.path.exists(db_file):
        return None
    backup_dir = backup_dir or os.path.join(os.path.dirname(os.path.abspath(db_file)), "db_backups")
    os.makedirs(backup_dir, exist_ok=True)
    dest = os.path.join(backup_dir, f"{tag}-{datetime.now().strftime('%Y%m%d-%H%M%S')}.db")
    src = sqlite3.connect(db_file, timeout=30)
    try:
        dst = sqlite3.connect(dest)
        try:
            src.backup(dst)
        finally:
            dst.close()
    finally:
        src.close()
    return dest


LAST_BACKUP = None


def pending_migrations(conn):
    conn.execute("""CREATE TABLE IF NOT EXISTS svm_schema_migrations(
        version INTEGER PRIMARY KEY, name TEXT NOT NULL, applied_at TEXT NOT NULL)""")
    done = {r[0] for r in conn.execute("SELECT version FROM svm_schema_migrations").fetchall()}
    return [m for m in MIGRATIONS if m[0] not in done]


def run_migrations(conn, db_file=None, backup=True):
    """Apply pending, additive migrations in order. Each migration is one transaction.
    A backup is taken first when something is pending and the database already holds data."""
    todo = pending_migrations(conn)
    if not todo:
        return []
    backup_path = None
    if backup and db_file and _table_exists(conn, "vps"):
        try:
            backup_path = backup_database(db_file)
        except Exception:                       # a failed backup must never be silent
            raise RuntimeError("pre-migration backup failed - refusing to migrate")
    applied = []
    for version, name, fn in todo:
        try:
            conn.commit()
            conn.execute("BEGIN IMMEDIATE")
            fn(conn)
            conn.execute("INSERT INTO svm_schema_migrations(version,name,applied_at) VALUES(?,?,?)", (version, name, now_iso()))
            conn.commit()
            applied.append((version, name))
        except Exception:
            conn.rollback()
            raise
    global LAST_BACKUP
    LAST_BACKUP = backup_path
    return applied


# --------------------------------------------------------------------------- redaction
_SENSITIVE_KEYS = {"email", "contact", "vpa", "card", "card_id", "bank", "wallet", "acquirer_data", "billing_address",
                   "shipping_address", "customer_details", "upi", "phone", "ip", "customer_email", "customer_phone"}


def redact_event(obj):
    """Copy of a gateway event safe to store: personal/payment-instrument fields are replaced."""
    if isinstance(obj, dict):
        return {k: ("[redacted]" if str(k).lower() in _SENSITIVE_KEYS else redact_event(v)) for k, v in obj.items()}
    if isinstance(obj, list):
        return [redact_event(v) for v in obj]
    return obj


# --------------------------------------------------------------------------- accounts
def ensure_account(conn, discord_id, display_name=""):
    ts = now_iso()
    conn.execute("INSERT OR IGNORE INTO svm_accounts(discord_id,display_name,created_at,updated_at) VALUES(?,?,?,?)",
                 (str(discord_id), display_name[:80], ts, ts))
    if display_name:
        conn.execute("UPDATE svm_accounts SET display_name=?, updated_at=? WHERE discord_id=? AND display_name!=?",
                     (display_name[:80], ts, str(discord_id), display_name[:80]))
    conn.commit()
    return dict(conn.execute("SELECT * FROM svm_accounts WHERE discord_id=?", (str(discord_id),)).fetchone())


def account_allowed_to_buy(account):
    if account["status"] != "active":
        return False, account.get("suspended_reason") or f"account is {account['status']}"
    return True, ""


# --------------------------------------------------------------------------- image validation
MAX_PIXELS = 40_000_000
_SIGNATURES = {"image/png": b"\x89PNG\r\n\x1a\n", "image/jpeg": b"\xff\xd8\xff", "image/gif": (b"GIF87a", b"GIF89a")}
_DANGEROUS = ((b"MZ", "Windows executable"), (b"\x7fELF", "Linux executable"), (b"#!", "script"), (b"PK\x03\x04", "archive"),
              (b"%PDF", "PDF document"), (b"<?php", "PHP script"), (b"<html", "HTML"), (b"<svg", "SVG (scriptable)"), (b"<?xml", "XML/SVG"))


def _png_dims(d):
    if len(d) < 24 or d[12:16] != b"IHDR":
        return None
    w, h = struct.unpack(">II", d[16:24])
    return (w, h) if b"IEND" in d[-16:] else None          # truncated file -> malformed


def _gif_dims(d):
    if len(d) < 11:
        return None
    w, h = struct.unpack("<HH", d[6:10])
    return (w, h) if d[-1:] == b";" else None


def _jpeg_dims(d):
    i, n = 2, len(d)
    while i + 9 < n:
        if d[i] != 0xFF:
            i += 1
            continue
        marker = d[i + 1]
        if marker in (0xD8, 0x01) or 0xD0 <= marker <= 0xD7:
            i += 2
            continue
        if marker == 0xFF:
            i += 1
            continue
        if marker == 0xD9:
            return None
        seglen = struct.unpack(">H", d[i + 2:i + 4])[0]
        if 0xC0 <= marker <= 0xCF and marker not in (0xC4, 0xC8, 0xCC):
            h, w = struct.unpack(">HH", d[i + 5:i + 9])
            return (w, h) if b"\xff\xd9" in d[-64:] else None
        i += 2 + seglen
    return None


def _webp_dims(d):
    if len(d) < 30 or d[:4] != b"RIFF" or d[8:12] != b"WEBP":
        return None
    kind = d[12:16]
    if kind == b"VP8X":
        return (1 + int.from_bytes(d[24:27], "little"), 1 + int.from_bytes(d[27:30], "little"))
    if kind == b"VP8 ":
        w, h = struct.unpack("<HH", d[26:30])
        return (w & 0x3FFF, h & 0x3FFF)
    if kind == b"VP8L" and d[20] == 0x2F:
        bits = int.from_bytes(d[21:25], "little")
        return ((bits & 0x3FFF) + 1, ((bits >> 14) & 0x3FFF) + 1)
    return None


def validate_image(data: bytes, max_bytes: int = 8 * 1024 * 1024):
    """-> dict(ok, mime, ext, width, height, reason). Never trusts the client MIME type."""
    bad = lambda why: {"ok": False, "mime": "", "ext": "", "width": 0, "height": 0, "reason": why}
    if not data:
        return bad("empty file")
    if len(data) > max_bytes:
        return bad(f"file larger than {max_bytes // (1024 * 1024)} MB")
    head = data[:16].lower() if data[:1] == b"<" else data[:16]
    for sig, label in _DANGEROUS:
        if head.startswith(sig.lower() if sig.startswith(b"<") else sig):
            return bad(f"not an image ({label})")
    mime = dims = None
    if data.startswith(_SIGNATURES["image/png"]):
        mime, dims = "image/png", _png_dims(data)
    elif data.startswith(_SIGNATURES["image/jpeg"]):
        mime, dims = "image/jpeg", _jpeg_dims(data)
    elif data.startswith(_SIGNATURES["image/gif"]):
        mime, dims = "image/gif", _gif_dims(data)
    elif data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        mime, dims = "image/webp", _webp_dims(data)
    else:
        return bad("unsupported file type (allowed: PNG, JPEG, WEBP, GIF)")
    if not dims or dims[0] <= 0 or dims[1] <= 0:
        return bad("malformed or truncated image")
    if dims[0] > 12000 or dims[1] > 12000 or dims[0] * dims[1] > MAX_PIXELS:
        return bad("image dimensions are unreasonable (possible decompression bomb)")
    try:                                                    # optional deep check when Pillow exists
        from PIL import Image
        Image.MAX_IMAGE_PIXELS = MAX_PIXELS
        with Image.open(io.BytesIO(data)) as im:
            im.verify()
    except ImportError:
        pass
    except Exception:
        return bad("image failed integrity verification")
    ext = {"image/png": "png", "image/jpeg": "jpg", "image/gif": "gif", "image/webp": "webp"}[mime]
    return {"ok": True, "mime": mime, "ext": ext, "width": dims[0], "height": dims[1], "reason": ""}


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


# --------------------------------------------------------------------------- OCR (evidence only)
def ocr_available():
    if not shutil.which("tesseract"):
        return False
    try:
        import pytesseract  # noqa: F401
        from PIL import Image  # noqa: F401
        return True
    except ImportError:
        return False


def run_ocr(data: bytes, timeout: int = 25):
    """-> (text, mean_confidence_0_100). Raises RuntimeError when OCR is not installed."""
    if not ocr_available():
        raise RuntimeError("OCR is not installed (tesseract-ocr + pytesseract + pillow)")
    import pytesseract
    from PIL import Image
    Image.MAX_IMAGE_PIXELS = MAX_PIXELS
    with Image.open(io.BytesIO(data)) as im:
        im.load()
        img = im.convert("RGB")
    text = pytesseract.image_to_string(img, timeout=timeout)
    conf = None
    try:
        d = pytesseract.image_to_data(img, output_type=pytesseract.Output.DICT, timeout=timeout)
        vals = [float(c) for c in d.get("conf", []) if str(c).lstrip("-").replace(".", "", 1).isdigit() and float(c) >= 0]
        conf = sum(vals) / len(vals) if vals else None
    except Exception:
        pass
    return text[:8000], conf


_AMT = re.compile(r"(?:₹|rs\.?|inr)\s*([0-9][0-9,]*(?:\.[0-9]{1,2})?)", re.I)
_UTR_LABEL = re.compile(r"(?:utr|upi\s*(?:transaction|ref(?:erence)?)\s*(?:id|no\.?)?|ref(?:erence)?\s*(?:id|no\.?)|rrn|transaction\s*id|txn\s*id)\s*[:#\-]?\s*([A-Z0-9]{8,22})", re.I)
_UTR_BARE = re.compile(r"\b(\d{12})\b")
_DATE = re.compile(r"\b(\d{1,2})[/\-. ](\d{1,2}|[A-Za-z]{3,9})[/\-. ,]+(\d{2,4})\b")
_VPA = re.compile(r"\b([A-Za-z0-9._\-]{2,64}@[A-Za-z][A-Za-z0-9]{1,30})\b")
_SUCCESS = re.compile(r"\b(success(?:ful(?:ly)?)?|completed|paid|payment\s+done)\b", re.I)
_FAILED = re.compile(r"\b(fail(?:ed|ure)?|declined|rejected|cancel(?:l)?ed|pending|processing|reversed|refunded)\b", re.I)
_MONTHS = {m: i for i, m in enumerate(("jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"), 1)}


def normalise_reference(ref: str) -> str:
    return re.sub(r"[^A-Z0-9]", "", str(ref or "").upper())


def _to_paise(txt):
    try:
        return int((Decimal(txt.replace(",", "")) * 100).to_integral_value())
    except (InvalidOperation, ValueError):
        return None


def parse_ocr_text(text: str):
    """Extract candidate fields from OCR text. Every field carries a confidence label; none is authoritative."""
    text = text or ""
    out = {"amounts": [], "utr": [], "dates": [], "vpas": [], "status": "", "status_confidence": "none"}
    for m in _AMT.finditer(text):
        p = _to_paise(m.group(1))
        if p and p not in [a["paise"] for a in out["amounts"]]:
            out["amounts"].append({"paise": p, "confidence": "high"})      # preceded by a currency marker
    seen = set()
    for m in _UTR_LABEL.finditer(text):
        v = normalise_reference(m.group(1))
        if len(v) >= 8 and v not in seen:
            seen.add(v)
            out["utr"].append({"value": v, "confidence": "high"})
    for m in _UTR_BARE.finditer(text):
        v = m.group(1)
        if v not in seen:
            seen.add(v)
            out["utr"].append({"value": v, "confidence": "low"})
    for m in _DATE.finditer(text):
        d, mo, y = m.group(1), m.group(2), m.group(3)
        try:
            mo_i = int(mo) if mo.isdigit() else _MONTHS.get(mo[:3].lower())
            y_i = int(y) + (2000 if len(y) == 2 else 0)
            dt = datetime(y_i, mo_i, int(d))
            out["dates"].append({"value": dt.date().isoformat(), "confidence": "medium"})
        except (TypeError, ValueError):
            continue
    out["vpas"] = sorted({m.group(1).lower() for m in _VPA.finditer(text)})
    ok, bad = bool(_SUCCESS.search(text)), bool(_FAILED.search(text))
    if bad and not ok:
        out["status"], out["status_confidence"] = "failed_or_pending", "medium"
    elif ok and not bad:
        out["status"], out["status_confidence"] = "success", "medium"
    elif ok and bad:
        out["status"], out["status_confidence"] = "ambiguous", "low"
    return out


def compare_proof_to_order(parsed, order, merchant_vpa="", now=None):
    """-> list of human flags. Never returns 'verified': a screenshot is supporting evidence only."""
    now = now or datetime.now()
    order = dict(order)
    flags = []
    amounts = [a["paise"] for a in parsed.get("amounts", [])]
    if not amounts:
        flags.append("amount_not_found")
    elif int(order["amount_paise"]) not in amounts:
        flags.append("amount_mismatch")
    if parsed.get("status") == "failed_or_pending":
        flags.append("status_not_success")
    elif parsed.get("status") in ("", "ambiguous"):
        flags.append("status_unclear")
    if merchant_vpa and parsed.get("vpas") and merchant_vpa.lower() not in parsed["vpas"]:
        flags.append("payee_mismatch")
    if not parsed.get("utr"):
        flags.append("reference_not_found")
    try:
        created = datetime.fromisoformat(str(order["created_at"]))
        for d in parsed.get("dates", []):
            when = datetime.fromisoformat(d["value"])
            if when.date() < (created - timedelta(days=1)).date():
                flags.append("date_before_order")
                break
            if when.date() > (now + timedelta(days=1)).date():
                flags.append("date_in_future")
                break
    except (ValueError, TypeError, KeyError):
        pass
    if order.get("status") == "expired":
        flags.append("order_expired")
    return flags


def find_duplicates(conn, sha256, utr_candidates, order_id):
    """Reuse detection across orders: identical file hash, or a reference already claimed/seen on another order."""
    flags = []
    row = conn.execute("SELECT order_id FROM v112v_payment_proofs WHERE sha256=? AND order_id!=? AND deleted_at IS NULL LIMIT 1",
                       (sha256, int(order_id))).fetchone()
    if row:
        flags.append(f"reused_screenshot(order {row[0]})")
    for u in utr_candidates:
        v = normalise_reference(u)
        r = conn.execute("SELECT order_id FROM svm_utr_registry WHERE utr=? AND order_id!=?", (v, int(order_id))).fetchone()
        if not r:
            r = conn.execute("SELECT order_id FROM v112v_payment_proofs WHERE ocr_utr=? AND order_id!=? AND deleted_at IS NULL LIMIT 1",
                             (v, int(order_id))).fetchone()
        if r:
            flags.append(f"reused_reference(order {r[0]})")
            break
    return flags


def store_proof_file(proof_dir, order_id, digest, ext, data):
    os.makedirs(proof_dir, mode=0o700, exist_ok=True)
    try:
        os.chmod(proof_dir, 0o700)
    except OSError:
        pass
    path = os.path.join(proof_dir, f"{int(order_id)}-{digest[:20]}.{ext}")
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "wb") as f:
        f.write(data)
    return path


def purge_expired_proofs(conn, now=None):
    """Delete evidence files past their retention date (row is kept, file removed)."""
    now = (now or datetime.now()).isoformat(timespec="seconds")
    n = 0
    for r in conn.execute("SELECT id,path FROM v112v_payment_proofs WHERE purge_after IS NOT NULL AND purge_after<=? AND deleted_at IS NULL", (now,)).fetchall():
        try:
            if r["path"] and os.path.exists(r["path"]):
                os.remove(r["path"])
        except OSError:
            continue
        conn.execute("UPDATE v112v_payment_proofs SET deleted_at=?, path='' WHERE id=?", (now, r["id"]))
        n += 1
    conn.commit()
    return n


# --------------------------------------------------------------------------- manual UPI review
_VPA_RE = re.compile(r"^[A-Za-z0-9._\-]{2,64}@[A-Za-z][A-Za-z0-9]{1,30}$")


def valid_vpa(vpa: str) -> bool:
    return bool(_VPA_RE.match(vpa or ""))


def parse_inr(text) -> int | None:
    """'1,499.00' -> 149900 paise; None when invalid / not positive."""
    try:
        v = Decimal(str(text).replace(",", "").replace("₹", "").strip())
    except InvalidOperation:
        return None
    if v <= 0 or v > Decimal("10000000"):
        return None
    p = (v * 100)
    return int(p) if p == p.to_integral_value() else None


def mark_review_required(conn, order_id):
    cur = conn.execute("UPDATE v112v_orders SET status='review_required' WHERE id=? AND provider='upi' AND status IN ('created','expired')", (int(order_id),))
    conn.commit()
    return cur.rowcount == 1


def approve_manual(conn, order_id, reviewer_id, bank_reference, amount_paise, note=""):
    """Authorised-reviewer approval of a MANUAL UPI order.
    The reviewer must independently confirm the credit (bank statement / UPI app) and type the bank
    reference + amount they saw. Returns (ok, message). Does not provision - the caller schedules that."""
    order = conn.execute("SELECT * FROM v112v_orders WHERE id=?", (int(order_id),)).fetchone()
    if not order:
        return False, "order not found"
    if order["provider"] != "upi":
        return False, "only manual UPI orders can be approved by hand (gateway orders are verified automatically)"
    if order["status"] not in ORDER_OPEN_STATES:
        return False, f"order is `{order['status']}`, not awaiting review"
    if str(reviewer_id) == str(order["user_id"]):
        return False, "you cannot approve your own order"
    ref = normalise_reference(bank_reference)
    if not 8 <= len(ref) <= 32:
        return False, "bank reference must be 8-32 letters/digits (the UTR/RRN from your bank statement)"
    if int(amount_paise or -1) != int(order["amount_paise"]):
        return False, f"amount mismatch: order is INR {order['amount_paise'] / 100:.2f}"
    try:
        conn.commit()
        conn.execute("BEGIN IMMEDIATE")
        conn.execute("INSERT INTO svm_utr_registry(utr,order_id,source,created_at) VALUES(?,?,?,?)", (ref, int(order_id), "manual-review", now_iso()))
        cur = conn.execute("UPDATE v112v_orders SET status='paid', provider_payment_id=?, verified_at=?, review_note=? "
                           "WHERE id=? AND status IN ('created','expired','review_required')",
                           (f"upi:{ref}", now_iso(), note[:300], int(order_id)))
        if cur.rowcount != 1:
            conn.rollback()
            return False, "order changed state while approving"
        conn.execute("INSERT INTO svm_payment_reviews(order_id,reviewer_id,decision,bank_reference,amount_paise,reason,created_at) VALUES(?,?,?,?,?,?,?)",
                     (int(order_id), str(reviewer_id), "approved", ref, int(amount_paise), note[:300], now_iso()))
        conn.commit()
    except sqlite3.IntegrityError:
        conn.rollback()
        used = conn.execute("SELECT order_id FROM svm_utr_registry WHERE utr=?", (ref,)).fetchone()
        return False, f"that bank reference was already used for order #{used[0] if used else '?'}"
    return True, "approved"


def reject_manual(conn, order_id, reviewer_id, reason):
    reason = (reason or "").strip()
    if len(reason) < 3:
        return False, "a reason is required"
    cur = conn.execute("UPDATE v112v_orders SET status='rejected', review_note=? WHERE id=? AND provider='upi' "
                       "AND status IN ('created','expired','review_required')", (reason[:300], int(order_id)))
    if cur.rowcount != 1:
        conn.rollback()
        return False, "only open manual UPI orders can be rejected"
    conn.execute("INSERT INTO svm_payment_reviews(order_id,reviewer_id,decision,reason,created_at) VALUES(?,?,?,?,?)",
                 (int(order_id), str(reviewer_id), "rejected", reason[:300], now_iso()))
    conn.commit()
    return True, "rejected"


# --------------------------------------------------------------------------- invoices + refunds
def issue_invoice(conn, order):
    """Idempotent: one invoice per order. Number format INV-YYYYMM-000123."""
    order = dict(order)
    row = conn.execute("SELECT invoice_no FROM svm_invoices WHERE order_id=?", (int(order["id"]),)).fetchone()
    if row:
        return row[0]
    ts = datetime.now()
    seq = (conn.execute("SELECT COALESCE(MAX(id),0)+1 FROM svm_invoices").fetchone()[0])
    no = f"INV-{ts.strftime('%Y%m')}-{seq:06d}"
    try:
        conn.execute("INSERT INTO svm_invoices(invoice_no,order_id,user_id,plan_slug,kind,amount_paise,currency,provider,created_at) VALUES(?,?,?,?,?,?,?,?,?)",
                     (no, int(order["id"]), str(order["user_id"]), order.get("plan_slug"),
                      order.get("kind") or "new", int(order["amount_paise"]), "INR",
                      order["provider"], ts.isoformat(timespec="seconds")))
        conn.commit()
    except sqlite3.IntegrityError:
        conn.rollback()
        return conn.execute("SELECT invoice_no FROM svm_invoices WHERE order_id=?", (int(order["id"]),)).fetchone()[0]
    return no


def request_refund(conn, order_id, requester_id, requester_is_admin, reason):
    order = conn.execute("SELECT * FROM v112v_orders WHERE id=?", (int(order_id),)).fetchone()
    if not order or (str(order["user_id"]) != str(requester_id) and not requester_is_admin):
        return False, "order not found on your account"
    if order["status"] not in ("paid", "fulfilling", "provisioned", "renewed"):
        return False, f"order is `{order['status']}`; only paid orders can be refunded"
    if conn.execute("SELECT 1 FROM svm_refunds WHERE order_id=? AND status IN ('requested','approved')", (int(order_id),)).fetchone():
        return False, "a refund request is already open for this order"
    ts = now_iso()
    conn.execute("INSERT INTO svm_refunds(order_id,user_id,status,reason,requested_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?)",
                 (int(order_id), str(order["user_id"]), "requested", (reason or "")[:500], str(requester_id), ts, ts))
    conn.commit()
    return True, "refund request recorded"


def decide_refund(conn, refund_id, admin_id, decision, note=""):
    """decision: denied | refunded. 'refunded' only records that the admin issued it in the gateway dashboard."""
    if decision not in ("denied", "refunded"):
        return False, "decision must be `denied` or `refunded`"
    row = conn.execute("SELECT * FROM svm_refunds WHERE id=?", (int(refund_id),)).fetchone()
    if not row or row["status"] not in ("requested", "approved"):
        return False, "refund request not found or already decided"
    conn.execute("UPDATE svm_refunds SET status=?, decided_by=?, decision_note=?, updated_at=? WHERE id=?",
                 (decision, str(admin_id), note[:300], now_iso(), int(refund_id)))
    if decision == "refunded":
        conn.execute("UPDATE v112v_orders SET status='refunded' WHERE id=?", (row["order_id"],))
    conn.commit()
    return True, decision


# --------------------------------------------------------------------------- command runner + capabilities
def default_run(argv, timeout=15):
    """Safe subprocess: argv list, no shell. -> (rc, stdout, stderr). rc 127 = binary missing, 124 = timeout."""
    try:
        p = subprocess.run(list(argv), capture_output=True, text=True, timeout=timeout, shell=False)
        return p.returncode, p.stdout.strip(), p.stderr.strip()
    except FileNotFoundError:
        return 127, "", f"{argv[0]}: not found"
    except subprocess.TimeoutExpired:
        return 124, "", "timed out"
    except OSError as e:
        return 126, "", str(e)[:200]


def _cpu_virt_flag(read=None):
    try:
        if read:
            text = read()
        else:
            with open("/proc/cpuinfo") as fh:
                text = fh.read()
    except OSError:
        return None
    flags = set(re.findall(r"\b(vmx|svm)\b", text))
    return bool(flags)


def detect_kvm(which=shutil.which, exists=os.path.exists, access=os.access, run=default_run, read_cpuinfo=None):
    c = {"dev_kvm": exists("/dev/kvm"), "dev_kvm_rw": bool(exists("/dev/kvm") and access("/dev/kvm", os.R_OK | os.W_OK)),
         "cpu_virt_flag": _cpu_virt_flag(read_cpuinfo),
         "qemu_system": bool(which("qemu-system-x86_64") or which("qemu-kvm")), "qemu_img": bool(which("qemu-img")),
         "virsh": bool(which("virsh")), "virt_install": bool(which("virt-install")),
         "seed_tool": bool(which("cloud-localds") or which("genisoimage") or which("mkisofs"))}
    c["libvirt_daemon"] = c["virsh"] and run(["virsh", "-c", "qemu:///system", "list", "--all"], 10)[0] == 0
    c["storage_pool"] = c["libvirt_daemon"] and "active" in run(["virsh", "-c", "qemu:///system", "pool-list"], 10)[1]
    c["network"] = c["libvirt_daemon"] and "active" in run(["virsh", "-c", "qemu:///system", "net-list"], 10)[1]
    needed = ("dev_kvm_rw", "qemu_system", "qemu_img", "virsh", "virt_install", "libvirt_daemon", "seed_tool", "storage_pool", "network")
    c["missing"] = [k for k in needed if not c[k]]
    c["ready"] = not c["missing"]
    return c


def detect_lxd(which=shutil.which, run=default_run):
    cli = "incus" if which("incus") else ("lxc" if which("lxc") else "")
    c = {"cli": cli, "installed": bool(cli), "daemon": False, "storage_pools": [], "networks": []}
    if cli:
        c["daemon"] = run([cli, "info"], 10)[0] == 0
        if c["daemon"]:
            rc, out, _ = run([cli, "storage", "list", "--format", "csv"], 10)
            c["storage_pools"] = [l.split(",")[0] for l in out.splitlines() if l.strip()] if rc == 0 else []
            rc, out, _ = run([cli, "network", "list", "--format", "csv"], 10)
            c["networks"] = [l.split(",")[0] for l in out.splitlines() if l.strip()] if rc == 0 else []
    c["missing"] = [k for k, ok in (("cli", c["installed"]), ("daemon", c["daemon"]), ("storage_pool", bool(c["storage_pools"]))) if not ok]
    c["ready"] = not c["missing"]
    return c


# --------------------------------------------------------------------------- providers
_NAME_RE = re.compile(r"^[a-z0-9][a-z0-9\-]{0,40}$")


class ProviderUnavailable(RuntimeError):
    pass


def allocate_vmid(conn, start=100):
    """Proxmox-style numeric guest id >= 100 with collision checks across every table that stores one."""
    used = set()
    for table, col in (("vps", "vmid"), ("v112v_vps_meta", "vmid")):
        if _table_exists(conn, table) and col in {r[1] for r in conn.execute(f"PRAGMA table_info({table})").fetchall()}:
            used |= {r[0] for r in conn.execute(f"SELECT {col} FROM {table} WHERE {col} IS NOT NULL").fetchall()}
    n = max(start, (max(used) + 1) if used else start)
    while n in used:
        n += 1
    return n


class ProviderBase:
    name = "base"

    def __init__(self, run=default_run, which=shutil.which):
        self.run, self.which = run, which

    def detect_capabilities(self): raise NotImplementedError
    def list_images(self): raise NotImplementedError
    def validate_plan(self, cpu, ram_gb, disk_gb):
        if not (1 <= int(cpu) <= 64 and 1 <= int(ram_gb) <= 512 and 1 <= int(disk_gb) <= 4096):
            raise ValueError("plan resources out of supported range")
        return True
    def create_instance(self, *a, **k): raise NotImplementedError
    def get_instance(self, name): raise NotImplementedError
    def list_instances(self): raise NotImplementedError
    def start_instance(self, name): raise NotImplementedError
    def stop_instance(self, name): raise NotImplementedError
    def restart_instance(self, name): raise NotImplementedError
    def delete_instance(self, name): raise NotImplementedError
    def get_console(self, name): raise NotImplementedError
    def get_usage(self, name): raise NotImplementedError
    def get_network_info(self, name): raise NotImplementedError

    @staticmethod
    def check_name(name):
        if not _NAME_RE.match(str(name or "")):
            raise ValueError("invalid instance name")
        return name


class LxdProvider(ProviderBase):
    """LXC containers / Incus / LXD VMs through the `lxc` or `incus` CLI (argv lists only)."""
    name = "lxc"

    @property
    def cli(self):
        return "incus" if self.which("incus") else "lxc"

    def detect_capabilities(self):
        return detect_lxd(self.which, self.run)

    def _need_ready(self):
        caps = self.detect_capabilities()
        if not caps["ready"]:
            raise ProviderUnavailable("LXC/Incus/LXD not ready: " + ", ".join(caps["missing"]))
        return caps

    def list_images(self):
        rc, out, _ = self.run([self.cli, "image", "list", "--format", "csv", "-c", "lfdasu"], 30)
        rows = []
        if rc == 0:
            for line in out.splitlines():
                p = line.split(",")
                if len(p) >= 4:
                    rows.append({"alias": p[0], "fingerprint": p[1], "description": p[2], "arch": p[3]})
        return rows

    def verify_image(self, alias, timeout=45):
        """Image must resolve on its source. -> (ok, arch, detail)."""
        if not re.fullmatch(r"[A-Za-z0-9._:/\-]{1,80}", alias or ""):
            return False, "", "invalid alias"
        rc, out, err = self.run([self.cli, "image", "info", alias], timeout)
        if rc != 0:
            return False, "", (err or "image not found")[:160]
        m = re.search(r"Architecture:\s*(\S+)", out)
        return True, (m.group(1) if m else ""), "verified"

    def create_instance(self, name, image, cpu, ram_gb, disk_gb, storage_pool, vm=False):
        self.check_name(name)
        self.validate_plan(cpu, ram_gb, disk_gb)
        self._need_ready()
        if not self.verify_image(image)[0]:
            raise ProviderUnavailable(f"image {image} is not available")
        cmd = [self.cli, "init", image, name, "-s", storage_pool, "-c", f"limits.cpu={int(cpu)}", "-c", f"limits.memory={int(ram_gb) * 1024}MiB",
               "-d", f"root,size={int(disk_gb)}GiB"]
        if vm:
            cmd.append("--vm")
        rc, out, err = self.run(cmd, 600)
        if rc != 0:
            raise RuntimeError(f"create failed: {(err or out)[:300]}")
        rc, out, err = self.run([self.cli, "start", name], 120)
        if rc != 0:
            raise RuntimeError(f"start failed: {(err or out)[:300]}")
        return self.get_instance(name)

    def get_instance(self, name):
        self.check_name(name)
        rc, out, err = self.run([self.cli, "list", f"^{name}$", "--format", "json"], 20)
        if rc != 0:
            raise RuntimeError((err or "list failed")[:200])
        data = json.loads(out or "[]")
        if not data:
            return None
        d = data[0]
        addrs = []
        for net in ((d.get("state") or {}).get("network") or {}).values():
            for a in net.get("addresses", []):
                if a.get("family") == "inet" and a.get("scope") == "global":
                    addrs.append(a["address"])
        return {"name": d.get("name"), "status": str(d.get("status", "")).lower(), "type": d.get("type", "container"), "addresses": addrs}

    def list_instances(self):
        rc, out, _ = self.run([self.cli, "list", "--format", "json"], 30)
        return [{"name": d.get("name"), "status": str(d.get("status", "")).lower()} for d in json.loads(out or "[]")] if rc == 0 else []

    def _act(self, verb, name, extra=()):
        self.check_name(name)
        rc, out, err = self.run([self.cli, verb, name, *extra], 120)
        if rc != 0:
            raise RuntimeError(f"{verb} failed: {(err or out)[:200]}")
        return True

    def start_instance(self, name): return self._act("start", name)
    def stop_instance(self, name): return self._act("stop", name, ("--timeout", "60"))
    def restart_instance(self, name): return self._act("restart", name, ("--timeout", "60"))
    def delete_instance(self, name): return self._act("delete", name, ("--force",))
    def get_console(self, name): self.check_name(name); return f"{self.cli} exec {name} -- bash   (host admin only)"

    def get_usage(self, name):
        inst = self.get_instance(name)
        return {"status": inst["status"] if inst else "missing"}

    def get_network_info(self, name):
        inst = self.get_instance(name)
        return {"addresses": inst["addresses"] if inst else [], "note": "addresses are PRIVATE bridge addresses unless a public IP is assigned by IPAM"}


class KvmProvider(ProviderBase):
    """KVM/QEMU through libvirt (virsh/virt-install/qemu-img). Refuses to act unless every prerequisite passed."""
    name = "kvm"
    URI = ["-c", "qemu:///system"]

    def detect_capabilities(self):
        return detect_kvm(which=self.which, run=self.run)

    def _need_ready(self):
        caps = self.detect_capabilities()
        if not caps["ready"]:
            raise ProviderUnavailable("KVM not available: missing " + ", ".join(caps["missing"]))
        return caps

    def list_images(self):
        base = os.getenv("KVM_IMAGE_DIR", "/var/lib/svm/images")
        try:
            return [{"alias": f, "path": os.path.join(base, f)} for f in sorted(os.listdir(base)) if f.endswith((".qcow2", ".img"))]
        except OSError:
            return []

    def cloud_init_user_data(self, hostname, root_password, ssh_key=""):
        lines = ["#cloud-config", f"hostname: {hostname}", "ssh_pwauth: true", "disable_root: false",
                 "chpasswd:", "  expire: false", "  list: |", f"    root:{root_password}"]
        if ssh_key:
            lines += ["ssh_authorized_keys:", f"  - {ssh_key}"]
        return "\n".join(lines) + "\n"

    def create_instance(self, name, base_image, cpu, ram_gb, disk_gb, root_password, workdir="/var/lib/svm/vms", network="default", ssh_key=""):
        self.check_name(name)
        self.validate_plan(cpu, ram_gb, disk_gb)
        self._need_ready()
        if not os.path.isfile(base_image):
            raise ProviderUnavailable(f"base image not found: {base_image}")
        vm_dir = os.path.join(workdir, name)
        os.makedirs(vm_dir, mode=0o700, exist_ok=False)                  # refuses to reuse an existing name
        disk, seed = os.path.join(vm_dir, "disk.qcow2"), os.path.join(vm_dir, "seed.iso")
        with open(os.path.join(vm_dir, "user-data"), "w") as f:
            f.write(self.cloud_init_user_data(name, root_password, ssh_key))
        with open(os.path.join(vm_dir, "meta-data"), "w") as f:
            f.write(f"instance-id: {name}\nlocal-hostname: {name}\n")
        for argv in ([ "qemu-img", "create", "-f", "qcow2", "-F", "qcow2", "-b", base_image, disk, f"{int(disk_gb)}G"],
                     (["cloud-localds", seed, os.path.join(vm_dir, "user-data"), os.path.join(vm_dir, "meta-data")]
                      if self.which("cloud-localds") else
                      [self.which("genisoimage") and "genisoimage" or "mkisofs", "-output", seed, "-volid", "cidata", "-joliet", "-rock",
                       os.path.join(vm_dir, "user-data"), os.path.join(vm_dir, "meta-data")])):
            rc, out, err = self.run(argv, 300)
            if rc != 0:
                raise RuntimeError(f"{argv[0]} failed: {(err or out)[:200]}")
        rc, out, err = self.run(["virt-install", *self.URI, "--name", name, "--memory", str(int(ram_gb) * 1024), "--vcpus", str(int(cpu)),
                                 "--disk", f"path={disk},format=qcow2,bus=virtio", "--disk", f"path={seed},device=cdrom",
                                 "--import", "--os-variant", "detect=on,require=off", "--network", f"network={network}",
                                 "--graphics", "none", "--noautoconsole"], 300)
        if rc != 0:
            raise RuntimeError(f"virt-install failed: {(err or out)[:300]}")
        return self.get_instance(name)

    def get_instance(self, name):
        self.check_name(name)
        rc, out, err = self.run(["virsh", *self.URI, "domstate", name], 15)
        if rc != 0:
            return None
        addrs = []
        rc2, out2, _ = self.run(["virsh", *self.URI, "domifaddr", name], 15)
        if rc2 == 0:
            addrs = re.findall(r"ipv4\s+(\d+\.\d+\.\d+\.\d+)/", out2)
        return {"name": name, "status": out.strip().lower(), "type": "kvm", "addresses": addrs}

    def list_instances(self):
        rc, out, _ = self.run(["virsh", *self.URI, "list", "--all", "--name"], 20)
        return [{"name": n.strip()} for n in out.splitlines() if n.strip()] if rc == 0 else []

    def _virsh(self, verb, name, extra=()):
        self.check_name(name)
        rc, out, err = self.run(["virsh", *self.URI, verb, name, *extra], 90)
        if rc != 0:
            raise RuntimeError(f"{verb} failed: {(err or out)[:200]}")
        return True

    def start_instance(self, name): return self._virsh("start", name)
    def stop_instance(self, name): return self._virsh("shutdown", name)
    def restart_instance(self, name): return self._virsh("reboot", name)

    def delete_instance(self, name):
        self.check_name(name)
        self.run(["virsh", *self.URI, "destroy", name], 60)
        return self._virsh("undefine", name, ("--remove-all-storage", "--nvram"))

    def get_console(self, name): self.check_name(name); return f"virsh -c qemu:///system console {name}   (host admin only)"
    def get_usage(self, name): inst = self.get_instance(name); return {"status": inst["status"] if inst else "missing"}
    def get_network_info(self, name):
        inst = self.get_instance(name)
        return {"addresses": inst["addresses"] if inst else [], "note": "libvirt NAT addresses are PRIVATE"}


# --------------------------------------------------------------------------- OS catalog
DEFAULT_OS_ALLOWLIST = (
    "ubuntu:20.04|Ubuntu 20.04 LTS,"
    "ubuntu:22.04|Ubuntu 22.04 LTS,"
    "ubuntu:24.04|Ubuntu 24.04 LTS,"
    "images:debian/10|Debian 10 (Buster),"
    "images:debian/11|Debian 11 (Bullseye),"
    "images:debian/12|Debian 12 (Bookworm),"
    "images:debian/13|Debian 13 (Trixie),"
    "images:almalinux/8|AlmaLinux 8,"
    "images:almalinux/9|AlmaLinux 9,"
    "images:rockylinux/8|Rocky Linux 8,"
    "images:rockylinux/9|Rocky Linux 9,"
    "images:centos/9-Stream|CentOS Stream 9,"
    "images:fedora/40|Fedora 40,"
    "images:fedora/41|Fedora 41,"
    "images:alpine/3.20|Alpine Linux 3.20,"
    "images:archlinux|Arch Linux,"
    "images:oracle/9|Oracle Linux 9,"
    "images:opensuse/15.6|openSUSE Leap 15.6,"
    "images:kali/current|Kali Linux"
)


def parse_os_allowlist(raw=None):
    out = []
    for item in (raw or DEFAULT_OS_ALLOWLIST).split(","):
        alias, _, label = item.strip().partition("|")
        if re.fullmatch(r"[A-Za-z0-9._:/\-]{1,80}", alias or ""):
            out.append((alias, (label or alias).strip()))
    return out


def refresh_os_catalog(conn, provider: LxdProvider, allowlist):
    """Verify every allowlisted alias against the real image source and cache the outcome."""
    for alias, label in allowlist:
        ok, arch, detail = provider.verify_image(alias)
        conn.execute("INSERT INTO svm_os_images(alias,label,provider,arch,status,detail,checked_at) VALUES(?,?,?,?,?,?,?) "
                     "ON CONFLICT(alias) DO UPDATE SET label=excluded.label, arch=excluded.arch, status=excluded.status, "
                     "detail=excluded.detail, checked_at=excluded.checked_at",
                     (alias, label, "lxc", arch, "verified" if ok else "unavailable", detail, now_iso()))
    conn.commit()


def verified_os(conn):
    return [dict(r) for r in conn.execute("SELECT * FROM svm_os_images WHERE status='verified' ORDER BY label").fetchall()]


def os_is_verified(conn, alias):
    return conn.execute("SELECT 1 FROM svm_os_images WHERE alias=? AND status='verified'", (alias,)).fetchone() is not None


if __name__ == "__main__":                                   # python3 svm12.py migrate-check|migrate|version <db>
    import sys, tempfile
    cmd = sys.argv[1] if len(sys.argv) > 1 else "version"
    if cmd == "version":
        print(V12_VERSION)
    elif cmd in ("migrate-check", "migrate") and len(sys.argv) > 2:
        target = sys.argv[2]
        work = target
        if cmd == "migrate-check":                           # never touches the real database
            work = os.path.join(tempfile.mkdtemp(prefix="svm12-migrate-"), "copy.db")
            shutil.copy2(target, work)
        conn = sqlite3.connect(work, timeout=30)
        conn.row_factory = sqlite3.Row
        try:
            done = run_migrations(conn, db_file=work if cmd == "migrate" else None, backup=(cmd == "migrate"))
            print(f"{cmd}: {len(done)} migration(s) applied" + (f" (backup: {LAST_BACKUP})" if LAST_BACKUP else ""))
        except Exception as e:
            print(f"{cmd} FAILED: {e}", file=sys.stderr)
            sys.exit(1)
        finally:
            conn.close()
    else:
        print("usage: svm12.py version | migrate-check <db> | migrate <db>")
        sys.exit(2)
