import sys, types

class Meta(type):
    def __getattr__(cls, n):
        if n.startswith('__'): raise AttributeError(n)
        return Dummy()
    def __iter__(cls): return iter(())

class Dummy(metaclass=Meta):
    """Permissive stand-in: attribute access / calls / subclassing all work; decorators return the function."""
    def __init__(self, *a, **k): pass
    def __call__(self, *a, **k):
        if len(a) == 1 and callable(a[0]) and not k and not isinstance(a[0], type):
            return a[0]
        return _Deco()
    def __getattr__(self, n):
        if n.startswith('__'): raise AttributeError(n)
        return Dummy()
    def __iter__(self): return iter(())
    def __or__(self, o): return self
    def __ror__(self, o): return self
    def is_running(self): return False

class _Deco:
    def __call__(self, f=None, *a, **k):
        return f if callable(f) else _Deco()
    def __getattr__(self, n):
        if n.startswith('__'): raise AttributeError(n)
        return Dummy()

class StubModule(types.ModuleType):
    def __getattr__(self, name):
        if name.startswith('__'): raise AttributeError(name)
        return Meta(name, (Dummy,), {})

def stub(name):
    m = StubModule(name); m.__path__ = []; sys.modules[name] = m; return m

for n in ['discord','discord.ext','discord.ext.commands','discord.ext.tasks','discord.ui','discord.errors','discord.utils','flask_cors','paramiko','cairosvg','discord.app_commands']:
    stub(n)
sys.modules['discord'].ext = sys.modules['discord.ext']
sys.modules['discord.ext'].commands = sys.modules['discord.ext.commands']
sys.modules['discord.ext'].tasks = sys.modules['discord.ext.tasks']
sys.modules['discord'].ui = sys.modules['discord.ui']
sys.modules['discord'].errors = sys.modules['discord.errors']
pm = sys.modules['paramiko']
class SSHException(Exception): pass
class AuthenticationException(SSHException): pass
pm.SSHException, pm.AuthenticationException = SSHException, AuthenticationException
sys.modules['flask_cors'].CORS = lambda app, *a, **k: app

import inspect as _insp
class FakeCmd:
    def __init__(self, f, name, aliases, hidden):
        self.callback, self.name, self.aliases, self.hidden = f, name, list(aliases or []), hidden
        self.help = (f.__doc__ or '').strip() or None; self.brief = None; self.checks = []
        try: self.signature = ' '.join(f'<{p}>' for p in list(_insp.signature(f).parameters)[1:])
        except Exception: self.signature = ''
        self.qualified_name = name
class FakeBot:
    def __init__(self, *a, **k): self.commands = []; self.loop = None
    def command(self, *a, **k):
        def deco(f):
            name = k.get('name') or (a[0] if a else f.__name__)
            self.commands = [c for c in self.commands if c.name != name]
            self.commands.append(FakeCmd(f, name, k.get('aliases'), k.get('hidden', False)))
            return f
        return deco
    hybrid_command = command
    def get_command(self, n):
        return next((c for c in self.commands if c.name == n or n in c.aliases), None)
    def __getattr__(self, n):
        if n.startswith('__'): raise AttributeError(n)
        return Dummy()
sys.modules['discord.ext.commands'].Bot = FakeBot


class Embed:
    """Faithful enough stand-in for discord.Embed so tests can assert on what users/staff would actually read."""
    def __init__(self, title=None, description=None, color=None, colour=None, **k):
        self.title, self.description, self.color, self.fields = title, description, color or colour, []
    def add_field(self, name=None, value=None, inline=True):
        self.fields.append((str(name), str(value))); return self
    def set_footer(self, *a, **k): return self
    def set_thumbnail(self, *a, **k): return self
    def set_image(self, *a, **k): return self
    def set_author(self, *a, **k): return self
sys.modules['discord'].Embed = Embed
