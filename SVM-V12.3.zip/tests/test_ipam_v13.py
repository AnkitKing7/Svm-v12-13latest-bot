"""
SVM V13 IPAM unit tests — pure calculation + concurrent allocation safety.
Run: pytest tests/test_ipam_v13.py -v
"""
from __future__ import annotations

import sqlite3
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

import pytest

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from svm_ipam import (
    IPAMService, AddrStatus, BindMode, Health,
    validate_cidr, network_info, expand_usable, pools_overlap,
    address_publicness, is_valid_hostname_label,
)


def _mem_conn():
    conn = sqlite3.connect(":memory:", check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def _shared_db():
    """Single in-memory DB shared across threads via URI."""
    # Use file-backed temp for true multi-connection concurrency
    import tempfile, os
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    def get():
        c = sqlite3.connect(path, check_same_thread=False, timeout=10)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA journal_mode=WAL")
        c.execute("PRAGMA busy_timeout=5000")
        return c
    return get, path


class TestCIDR:
    def test_validate_basic(self):
        net = validate_cidr("10.0.0.0/24")
        assert str(net.network_address) == "10.0.0.0"
        assert net.prefixlen == 24

    def test_network_info_usable(self):
        info = network_info("192.168.1.0/30")
        assert info["usable_count"] == 2
        assert "192.168.1.1" in info["usable"]
        assert info["is_private"] is True

    def test_expand_and_exclude(self):
        net, addrs, trunc = expand_usable("10.0.0.0/29", exclude=["10.0.0.1"])
        assert "10.0.0.1" not in addrs
        assert not trunc

    def test_overlap(self):
        assert pools_overlap("10.0.0.0/24", "10.0.0.128/25") is True
        assert pools_overlap("10.0.0.0/24", "10.1.0.0/24") is False

    def test_publicness(self):
        assert address_publicness("8.8.8.8") == "public"
        assert address_publicness("10.1.2.3") == "private"
        assert address_publicness("100.64.1.1") == "cgnat"
        assert address_publicness("127.0.0.1") == "loopback"

    def test_hostname_label(self):
        assert is_valid_hostname_label("vps-42") is True
        assert is_valid_hostname_label("-bad") is False
        assert is_valid_hostname_label("a" * 64) is False


class TestIPAMService:
    def setup_method(self):
        self.get, self.path = _shared_db()
        self.svc = IPAMService(self.get)
        self.svc.ensure_schema()

    def teardown_method(self):
        import os
        try:
            os.unlink(self.path)
        except OSError:
            pass

    def test_add_pool_and_list(self):
        pid, count, trunc = self.svc.add_pool("lab", "10.20.30.0/28", gateway="10.20.30.1")
        assert pid > 0
        assert count >= 10  # /28 has 14 hosts, minus gateway
        pools = self.svc.list_pools()
        assert any(p["name"] == "lab" for p in pools)

    def test_overlap_rejected(self):
        self.svc.add_pool("a", "10.0.0.0/24")
        with pytest.raises(ValueError, match="overlaps"):
            self.svc.add_pool("b", "10.0.0.0/25")

    def test_allocate_and_release(self):
        self.svc.add_pool("p", "10.9.9.0/29", gateway="10.9.9.1")
        row = self.svc.allocate("ct1", vps_id="v1", bind_mode=BindMode.RECORD.value)
        assert row is not None
        assert row["status"] == AddrStatus.ASSIGNED.value
        assert row["health"] == Health.RECORDED.value
        addr = row["address"]
        found = self.svc.find(address=addr)
        assert len(found) == 1
        assert self.svc.release(addr) is True
        inv = self.svc.inventory()
        assert inv["by_status"].get("available", 0) >= 1

    def test_concurrent_no_duplicate(self):
        """Parallel allocate must never assign the same address twice."""
        self.svc.add_pool("conc", "10.55.0.0/28", gateway="10.55.0.1")  # 14 usable - gw
        results = []
        errors = []

        def worker(i):
            try:
                r = self.svc.allocate(f"ct-{i}", vps_id=str(i), bind_mode="record")
                results.append(r["address"] if r else None)
            except Exception as e:
                errors.append(str(e))

        with ThreadPoolExecutor(max_workers=8) as ex:
            futs = [ex.submit(worker, i) for i in range(20)]
            for f in as_completed(futs):
                f.result()

        assigned = [a for a in results if a]
        assert len(assigned) == len(set(assigned)), f"Duplicates: {assigned}"
        assert len(errors) == 0
        # pool exhaustion for remaining
        assert None in results or len(assigned) <= 13

    def test_status_lifecycle(self):
        self.svc.add_pool("life", "10.66.0.0/30")
        row = self.svc.allocate("ct-life")
        addr = row["address"]
        assert self.svc.set_status(addr, AddrStatus.CONFIGURING.value, health=Health.INSTALLED.value)
        assert self.svc.set_status(addr, AddrStatus.ACTIVE.value, health=Health.VERIFIED.value,
                                   rule_handles="iptables:1")
        found = self.svc.find(address=addr)[0]
        assert found["status"] == "active"
        assert found["health"] == "verified"
