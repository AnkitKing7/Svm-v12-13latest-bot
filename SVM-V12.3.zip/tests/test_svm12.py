"""Unit tests for svm12.py (no Discord, no network, no real charges, no real VMs).
Run:  python3 -m unittest discover -s tests -v"""
import io, os, pathlib, sqlite3, struct, sys, tempfile, unittest, zlib
from datetime import datetime, timedelta

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import svm12


def make_png(w=64, h=48):
    def chunk(t, d):
        c = struct.pack(">I", len(d)) + t + d
        return c + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)
    raw = b"".join(b"\x00" + b"\xff\xff\xff" * w for _ in range(h))
    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0)) + chunk(b"IDAT", zlib.compress(raw)) + chunk(b"IEND", b"")


def legacy_db(path=None):
    """The schema the project already had before V12 (so upgrade tests are realistic) + one existing order & VPS."""
    conn = sqlite3.connect(path or ":memory:")
    conn.row_factory = sqlite3.Row
    conn.executescript("""
      CREATE TABLE vps(id INTEGER PRIMARY KEY, container_name TEXT, vmid INTEGER);
      CREATE TABLE v112v_orders(id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT NOT NULL, plan_slug TEXT NOT NULL,
        amount_paise INTEGER NOT NULL, currency TEXT DEFAULT 'INR', provider TEXT DEFAULT 'razorpay',
        provider_order_id TEXT UNIQUE, provider_payment_id TEXT UNIQUE, status TEXT DEFAULT 'created',
        screenshot_status TEXT DEFAULT 'none', created_at TEXT NOT NULL, verified_at TEXT, raw_event TEXT DEFAULT '',
        kind TEXT DEFAULT 'new', vps_container TEXT, gateway_ref TEXT, pay_url TEXT, gw_amount INTEGER);
      CREATE TABLE v112v_payment_proofs(id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER NOT NULL, user_id TEXT NOT NULL,
        sha256 TEXT NOT NULL, filename TEXT, ocr_text TEXT DEFAULT '', status TEXT DEFAULT 'received', created_at TEXT NOT NULL);
      CREATE TABLE svm_webhook_events(event_id TEXT PRIMARY KEY, gateway TEXT, received_at TEXT);
      CREATE TABLE svm_billing(id INTEGER PRIMARY KEY, user_id TEXT);
      INSERT INTO vps(container_name,vmid) VALUES('old-vps',100);
      INSERT INTO v112v_orders(user_id,plan_slug,amount_paise,status,created_at) VALUES('1','starter',49900,'provisioned','2026-01-01T00:00:00');
    """)
    conn.commit()
    return conn


def new_db():
    c = legacy_db()
    svm12.run_migrations(c, backup=False)
    return c


def add_order(conn, user="222", amount=49900, provider="upi", status="created", created=None):
    cur = conn.execute("INSERT INTO v112v_orders(user_id,plan_slug,amount_paise,provider,status,created_at,kind) VALUES(?,?,?,?,?,?,?)",
                       (user, "starter", amount, provider, status, created or svm12.now_iso(), "new"))
    conn.commit()
    return cur.lastrowid


class Migrations(unittest.TestCase):
    def test_upgrade_preserves_data_and_is_idempotent(self):
        with tempfile.TemporaryDirectory() as d:
            db = os.path.join(d, "vps.db")
            c = legacy_db(db)
            applied = svm12.run_migrations(c, db_file=db)
            self.assertEqual([v for v, _ in applied], [m[0] for m in svm12.MIGRATIONS])
            self.assertTrue(svm12.LAST_BACKUP and os.path.exists(svm12.LAST_BACKUP), "pre-migration backup must exist")
            self.assertEqual(c.execute("SELECT COUNT(*) FROM vps").fetchone()[0], 1)
            self.assertEqual(c.execute("SELECT status FROM v112v_orders WHERE id=1").fetchone()[0], "provisioned")
            cols = {r[1] for r in c.execute("PRAGMA table_info(v112v_orders)")}
            self.assertTrue({"os_image", "virt_provider", "review_note", "fulfilling_since"} <= cols)
            self.assertIn("result", {r[1] for r in c.execute("PRAGMA table_info(svm_webhook_events)")})
            self.assertEqual(svm12.run_migrations(c, db_file=db), [], "second run must be a no-op")
            b = sqlite3.connect(svm12.LAST_BACKUP or sorted(os.listdir(os.path.join(d, "db_backups")))[0])
            self.assertEqual(b.execute("SELECT COUNT(*) FROM vps").fetchone()[0], 1)

    def test_fresh_database(self):
        c = sqlite3.connect(":memory:"); c.row_factory = sqlite3.Row
        svm12.run_migrations(c, backup=False)
        for t in ("svm_accounts", "svm_payment_reviews", "svm_utr_registry", "svm_invoices", "svm_refunds", "svm_os_images"):
            self.assertIsNotNone(c.execute("SELECT 1 FROM sqlite_master WHERE name=?", (t,)).fetchone(), t)


class ImageValidation(unittest.TestCase):
    def test_valid_png(self):
        r = svm12.validate_image(make_png())
        self.assertTrue(r["ok"], r); self.assertEqual((r["mime"], r["width"], r["height"]), ("image/png", 64, 48))

    def test_valid_jpeg_and_webp_via_pillow(self):
        from PIL import Image
        for fmt, mime in (("JPEG", "image/jpeg"), ("WEBP", "image/webp"), ("GIF", "image/gif")):
            b = io.BytesIO(); Image.new("RGB", (40, 30), "white").save(b, fmt)
            r = svm12.validate_image(b.getvalue()); self.assertTrue(r["ok"], (fmt, r)); self.assertEqual(r["mime"], mime)

    def test_rejects_executables_scripts_archives_and_svg(self):
        for name, blob in (("exe", b"MZ" + b"\x00" * 200), ("elf", b"\x7fELF" + b"\x00" * 200), ("sh", b"#!/bin/sh\nrm -rf /\n"),
                           ("zip", b"PK\x03\x04" + b"\x00" * 100), ("pdf", b"%PDF-1.4 " + b"x" * 50),
                           ("svg", b"<svg xmlns='http://www.w3.org/2000/svg'><script>alert(1)</script></svg>"), ("php", b"<?php system($_GET[1]);")):
            self.assertFalse(svm12.validate_image(blob)["ok"], name)

    def test_rejects_png_disguised_exe_and_truncated(self):
        self.assertFalse(svm12.validate_image(b"MZ" + make_png())["ok"])
        self.assertFalse(svm12.validate_image(make_png()[:-20])["ok"], "truncated PNG")
        self.assertFalse(svm12.validate_image(b"\x89PNG\r\n\x1a\n" + b"junk" * 10)["ok"])

    def test_rejects_oversize_empty_and_decompression_bomb(self):
        self.assertFalse(svm12.validate_image(b"")["ok"])
        self.assertFalse(svm12.validate_image(make_png(), max_bytes=50)["ok"])
        bomb = bytearray(make_png()); bomb[16:24] = struct.pack(">II", 50000, 50000)
        r = svm12.validate_image(bytes(bomb)); self.assertFalse(r["ok"]); self.assertIn("dimension", r["reason"])


class OcrAndComparison(unittest.TestCase):
    TEXT = "Payment Successful\n₹499.00\nPaid to Ankit Hosting\nankit@okbank\nUPI Ref No: 412345678901\n12 Oct 2026, 10:32 AM"

    def test_parse_extracts_fields_with_confidence(self):
        p = svm12.parse_ocr_text(self.TEXT)
        self.assertEqual(p["amounts"][0]["paise"], 49900)
        self.assertEqual(p["utr"][0]["value"], "412345678901")
        self.assertEqual(p["dates"][0]["value"], "2026-10-12")
        self.assertIn("ankit@okbank", p["vpas"]); self.assertEqual(p["status"], "success")

    def test_matching_screenshot_still_is_not_verification(self):
        order = {"id": 1, "amount_paise": 49900, "created_at": "2026-10-12T09:00:00", "status": "created"}
        flags = svm12.compare_proof_to_order(svm12.parse_ocr_text(self.TEXT), order, "ankit@okbank", now=datetime(2026, 10, 12, 12))
        self.assertEqual(flags, [], flags)
        self.assertNotIn("verified", " ".join(flags))      # comparison only ever produces warnings

    def test_mismatches_are_flagged(self):
        order = {"id": 1, "amount_paise": 99900, "created_at": "2026-10-15T09:00:00", "status": "expired"}
        flags = svm12.compare_proof_to_order(svm12.parse_ocr_text(self.TEXT), order, "someone@else", now=datetime(2026, 10, 16))
        for f in ("amount_mismatch", "payee_mismatch", "date_before_order", "order_expired"):
            self.assertIn(f, flags)
        failed = svm12.parse_ocr_text("Payment failed\n₹499.00")
        self.assertIn("status_not_success", svm12.compare_proof_to_order(failed, {"id": 1, "amount_paise": 49900, "created_at": svm12.now_iso(), "status": "created"}))

    def test_duplicate_screenshot_and_reference_detection(self):
        c = new_db(); o1, o2 = add_order(c), add_order(c)
        c.execute("INSERT INTO v112v_payment_proofs(order_id,user_id,sha256,created_at,ocr_utr) VALUES(?,?,?,?,?)", (o1, "222", "abc", svm12.now_iso(), "412345678901")); c.commit()
        self.assertTrue(any("reused_screenshot" in f for f in svm12.find_duplicates(c, "abc", [], o2)))
        self.assertTrue(any("reused_reference" in f for f in svm12.find_duplicates(c, "zzz", ["412345678901"], o2)))
        self.assertEqual(svm12.find_duplicates(c, "abc", ["412345678901"], o1), [], "same order is not a reuse")

    def test_real_tesseract_ocr_if_installed(self):
        if not svm12.ocr_available():
            self.skipTest("BLOCKED: tesseract/pytesseract/Pillow not installed")
        from PIL import Image, ImageDraw, ImageFont
        img = Image.new("RGB", (900, 260), "white"); d = ImageDraw.Draw(img)
        f = ImageFont.load_default(size=48)
        d.text((20, 20), "Payment Successful", fill="black", font=f); d.text((20, 90), "Rs 499.00", fill="black", font=f)
        d.text((20, 160), "UTR: 412345678901", fill="black", font=f)
        b = io.BytesIO(); img.save(b, "PNG")
        text, conf = svm12.run_ocr(b.getvalue())
        p = svm12.parse_ocr_text(text)
        self.assertIn(49900, [a["paise"] for a in p["amounts"]], text)
        self.assertEqual(p["utr"][0]["value"], "412345678901", text)


class ManualReview(unittest.TestCase):
    def setUp(self):
        self.c = new_db()

    def test_approval_requires_reference_exact_amount_and_other_reviewer(self):
        o = add_order(self.c)
        self.assertFalse(svm12.approve_manual(self.c, o, "999", "SHORT", 49900)[0])               # reference too short
        self.assertFalse(svm12.approve_manual(self.c, o, "999", "412345678901", 40000)[0])        # wrong amount
        self.assertFalse(svm12.approve_manual(self.c, o, "222", "412345678901", 49900)[0])        # self approval
        self.assertEqual(self.c.execute("SELECT status FROM v112v_orders WHERE id=?", (o,)).fetchone()[0], "created")
        ok, msg = svm12.approve_manual(self.c, o, "999", "412345678901", 49900, "checked bank")
        self.assertTrue(ok, msg)
        r = self.c.execute("SELECT * FROM v112v_orders WHERE id=?", (o,)).fetchone()
        self.assertEqual((r["status"], r["provider_payment_id"]), ("paid", "upi:412345678901"))
        rev = self.c.execute("SELECT * FROM svm_payment_reviews WHERE order_id=?", (o,)).fetchone()
        self.assertEqual((rev["reviewer_id"], rev["decision"], rev["amount_paise"]), ("999", "approved", 49900))

    def test_same_bank_reference_cannot_pay_two_orders_and_double_approve_fails(self):
        a, b = add_order(self.c), add_order(self.c, user="333")
        self.assertTrue(svm12.approve_manual(self.c, a, "999", "UTR000111222333", 49900)[0])
        self.assertFalse(svm12.approve_manual(self.c, a, "999", "UTR000111222333", 49900)[0])
        ok, msg = svm12.approve_manual(self.c, b, "999", "utr000111222333", 49900)
        self.assertFalse(ok); self.assertIn("already used", msg)
        self.assertEqual(self.c.execute("SELECT status FROM v112v_orders WHERE id=?", (b,)).fetchone()[0], "created")

    def test_gateway_orders_cannot_be_hand_approved(self):
        o = add_order(self.c, provider="razorpay")
        ok, msg = svm12.approve_manual(self.c, o, "999", "412345678901", 49900)
        self.assertFalse(ok); self.assertIn("gateway", msg)

    def test_review_required_flow_and_reject_needs_reason(self):
        o = add_order(self.c)
        self.assertTrue(svm12.mark_review_required(self.c, o))
        self.assertFalse(svm12.reject_manual(self.c, o, "999", "")[0])
        self.assertTrue(svm12.reject_manual(self.c, o, "999", "no credit in bank")[0])
        self.assertEqual(self.c.execute("SELECT status FROM v112v_orders WHERE id=?", (o,)).fetchone()[0], "rejected")
        self.assertFalse(svm12.approve_manual(self.c, o, "999", "412345678901", 49900)[0], "rejected order cannot be approved")

    def test_utils(self):
        self.assertEqual(svm12.parse_inr("1,499.00"), 149900); self.assertIsNone(svm12.parse_inr("-5")); self.assertIsNone(svm12.parse_inr("abc"))
        self.assertIsNone(svm12.parse_inr("10.005"))
        self.assertTrue(svm12.valid_vpa("xxxd92@jo")); self.assertFalse(svm12.valid_vpa("no-at-sign")); self.assertFalse(svm12.valid_vpa("a b@c"))


class AccountsBillingStorage(unittest.TestCase):
    def test_account_unique_by_discord_id(self):
        c = new_db()
        a = svm12.ensure_account(c, 42, "Alice"); b = svm12.ensure_account(c, 42, "Alice Renamed")
        self.assertEqual(a["id"], b["id"]); self.assertEqual(b["display_name"], "Alice Renamed")
        self.assertEqual(c.execute("SELECT COUNT(*) FROM svm_accounts").fetchone()[0], 1)
        c.execute("UPDATE svm_accounts SET status='suspended', suspended_reason='abuse' WHERE discord_id='42'"); c.commit()
        self.assertFalse(svm12.account_allowed_to_buy(dict(c.execute("SELECT * FROM svm_accounts").fetchone()))[0])

    def test_invoice_idempotent_and_refund_flow(self):
        c = new_db(); o = add_order(c, status="provisioned", provider="razorpay")
        order = c.execute("SELECT * FROM v112v_orders WHERE id=?", (o,)).fetchone()
        n1, n2 = svm12.issue_invoice(c, order), svm12.issue_invoice(c, order)
        self.assertEqual(n1, n2); self.assertRegex(n1, r"^INV-\d{6}-\d{6}$")
        self.assertFalse(svm12.request_refund(c, o, "other-user", False, "x")[0], "ownership enforced")
        self.assertTrue(svm12.request_refund(c, o, "222", False, "not needed")[0])
        self.assertFalse(svm12.request_refund(c, o, "222", False, "again")[0], "no duplicate open request")
        rid = c.execute("SELECT id FROM svm_refunds").fetchone()[0]
        self.assertTrue(svm12.decide_refund(c, rid, "999", "refunded", "done in dashboard")[0])
        self.assertEqual(c.execute("SELECT status FROM v112v_orders WHERE id=?", (o,)).fetchone()[0], "refunded")

    def test_proof_file_permissions_and_retention(self):
        c = new_db(); o = add_order(c)
        with tempfile.TemporaryDirectory() as d:
            p = svm12.store_proof_file(os.path.join(d, "proofs"), o, "a" * 64, "png", make_png())
            self.assertEqual(oct(os.stat(p).st_mode & 0o777), "0o600"); self.assertEqual(oct(os.stat(os.path.dirname(p)).st_mode & 0o777), "0o700")
            c.execute("INSERT INTO v112v_payment_proofs(order_id,user_id,sha256,created_at,path,purge_after) VALUES(?,?,?,?,?,?)",
                      (o, "222", "a" * 64, svm12.now_iso(), p, (datetime.now() - timedelta(days=1)).isoformat(timespec="seconds"))); c.commit()
            self.assertEqual(svm12.purge_expired_proofs(c), 1); self.assertFalse(os.path.exists(p))

    def test_redaction_removes_personal_data_but_keeps_ids(self):
        ev = {"event": "payment.captured", "payload": {"payment": {"entity": {"id": "pay_1", "email": "a@b.c", "contact": "+911234567890",
              "vpa": "me@upi", "card": {"last4": "1111"}, "amount": 49900, "notes": {"order_id": "7"}}}}}
        s = str(svm12.redact_event(ev))
        for secret in ("a@b.c", "+911234567890", "me@upi", "1111"):
            self.assertNotIn(secret, s)
        self.assertIn("pay_1", s); self.assertIn("49900", s)

    def test_vmid_allocation_starts_at_100_without_collisions(self):
        c = new_db()
        self.assertEqual(svm12.allocate_vmid(c), 101, "100 is taken by the legacy vps row")
        c.execute("CREATE TABLE v112v_vps_meta(vps_db_id INTEGER PRIMARY KEY, vmid INTEGER UNIQUE)"); c.execute("INSERT INTO v112v_vps_meta VALUES(1,101)"); c.commit()
        self.assertEqual(svm12.allocate_vmid(c), 102)


class Providers(unittest.TestCase):
    @staticmethod
    def fake_run(responses):
        calls = []
        def run(argv, timeout=15):
            calls.append(list(argv))
            for key, val in responses.items():
                if key in " ".join(argv):
                    return val
            return (0, "", "")
        run.calls = calls
        return run

    def test_kvm_not_ready_when_dev_kvm_missing(self):
        caps = svm12.detect_kvm(which=lambda n: "/usr/bin/" + n, exists=lambda p: False, access=lambda *a: False,
                                run=self.fake_run({"list --all": (0, "", ""), "pool-list": (0, "default active", ""), "net-list": (0, "default active", "")}),
                                read_cpuinfo=lambda: "flags: vmx")
        self.assertFalse(caps["ready"]); self.assertIn("dev_kvm_rw", caps["missing"])

    def test_kvm_ready_only_when_everything_passes(self):
        caps = svm12.detect_kvm(which=lambda n: "/usr/bin/" + n, exists=lambda p: True, access=lambda *a: True,
                                run=self.fake_run({"list --all": (0, "", ""), "pool-list": (0, "default active", ""), "net-list": (0, "default active", "")}),
                                read_cpuinfo=lambda: "flags: vmx")
        self.assertTrue(caps["ready"], caps["missing"])
        caps2 = svm12.detect_kvm(which=lambda n: None if n == "virsh" else "/x", exists=lambda p: True, access=lambda *a: True, run=self.fake_run({}), read_cpuinfo=lambda: "")
        self.assertFalse(caps2["ready"]); self.assertFalse(caps2["libvirt_daemon"])

    def test_lxd_detection_with_mock(self):
        caps = svm12.detect_lxd(which=lambda n: "/snap/bin/lxc" if n == "lxc" else None,
                                run=self.fake_run({"storage list": (0, "default,dir,", ""), "network list": (0, "lxdbr0,bridge,", ""), " info": (0, "ok", "")}))
        self.assertTrue(caps["ready"], caps); self.assertEqual(caps["storage_pools"], ["default"])
        self.assertFalse(svm12.detect_lxd(which=lambda n: None, run=self.fake_run({}))["ready"])

    def test_kvm_provider_refuses_without_capability_and_never_uses_shell(self):
        prov = svm12.KvmProvider(run=self.fake_run({}), which=lambda n: None)
        with self.assertRaises(svm12.ProviderUnavailable):
            prov.create_instance("vm1", "/tmp/base.qcow2", 1, 2, 20, "pw")
        with self.assertRaises(ValueError):
            prov.check_name("vm; rm -rf /")

    def test_kvm_provider_lifecycle_commands_with_mocks(self):
        run = self.fake_run({"list --all": (0, "", ""), "pool-list": (0, "default active", ""), "net-list": (0, "default active", ""),
                             "domstate": (0, "running", ""), "domifaddr": (0, " vnet0 52:54 ipv4 192.168.122.50/24", "")})
        prov = svm12.KvmProvider(run=run, which=lambda n: "/usr/bin/" + n)
        orig_detect = svm12.detect_kvm
        svm12.detect_kvm = lambda **k: dict(orig_detect(which=lambda n: "/x", exists=lambda p: True, access=lambda *a: True, run=run, read_cpuinfo=lambda: "vmx"))
        try:
            with tempfile.TemporaryDirectory() as d:
                base = os.path.join(d, "base.qcow2"); pathlib.Path(base).write_bytes(b"x")
                inst = prov.create_instance("vm1", base, 2, 4, 40, "pw", workdir=os.path.join(d, "vms"))
                self.assertEqual(inst["status"], "running"); self.assertEqual(inst["addresses"], ["192.168.122.50"])
                joined = [" ".join(c) for c in run.calls]
                self.assertTrue(any(c.startswith("qemu-img create -f qcow2") and c.endswith("40G") for c in joined))
                vi = next(c for c in run.calls if c[0] == "virt-install")
                self.assertIn("4096", vi); self.assertIn("2", vi)
                self.assertEqual(oct(os.stat(os.path.join(d, "vms", "vm1")).st_mode & 0o777), "0o700")
                with self.assertRaises(FileExistsError):
                    prov.create_instance("vm1", base, 2, 4, 40, "pw", workdir=os.path.join(d, "vms"))
        finally:
            svm12.detect_kvm = orig_detect

    def test_lxd_provider_create_uses_argv_and_requires_verified_image(self):
        ok = {"image info": (0, "Architecture: x86_64\n", ""), " info": (0, "ok", ""), "storage list": (0, "default,dir", ""), "network list": (0, "lxdbr0,bridge", ""),
              "list ^": (0, '[{"name":"c1","status":"Running","type":"container","state":{"network":{"eth0":{"addresses":[{"family":"inet","scope":"global","address":"10.1.2.3"}]}}}}]', "")}
        run = self.fake_run(ok)
        prov = svm12.LxdProvider(run=run, which=lambda n: "/snap/bin/lxc" if n == "lxc" else None)
        inst = prov.create_instance("c1", "ubuntu:22.04", 2, 4, 40, "default")
        self.assertEqual(inst["addresses"], ["10.1.2.3"])
        init = next(c for c in run.calls if "init" in c)
        self.assertEqual(init[:4], ["lxc", "init", "ubuntu:22.04", "c1"]); self.assertIn("limits.memory=4096MiB", init)
        bad = svm12.LxdProvider(run=self.fake_run({**ok, "image info": (1, "", "not found")}), which=lambda n: "/x" if n == "lxc" else None)
        with self.assertRaises(svm12.ProviderUnavailable):
            bad.create_instance("c2", "ubuntu:99.99", 1, 1, 10, "default")
        with self.assertRaises(ValueError):
            prov.create_instance("../etc", "ubuntu:22.04", 1, 1, 10, "default")

    def test_os_catalog_only_lists_verified_images(self):
        c = new_db()
        run = self.fake_run({"debian/12": (1, "", "Image not found"), "image info": (0, "Architecture: x86_64\n", "")})
        prov = svm12.LxdProvider(run=run, which=lambda n: "/x" if n == "lxc" else None)
        svm12.refresh_os_catalog(c, prov, svm12.parse_os_allowlist())
        aliases = {r["alias"] for r in svm12.verified_os(c)}
        self.assertEqual(aliases, {"ubuntu:22.04", "ubuntu:24.04"})
        self.assertFalse(svm12.os_is_verified(c, "images:debian/12"))
        self.assertEqual(svm12.parse_os_allowlist("bad alias;rm|X,ubuntu:22.04|U"), [("ubuntu:22.04", "U")])


if __name__ == "__main__":
    unittest.main(verbosity=2)
