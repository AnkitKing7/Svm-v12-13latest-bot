# Architecture — SVM Advanced AI V14 (AnkitCoder)

```
Discord / Web Admin / FileManager
        |
        v
   bot.py  (commands, Flask :5000)
        |
   +----+----+---------+----------+
   v         v         v          v
svm_map   svm_ipam  svm_net   svm_topology
   |         |         |          |
   +----+----+----+----+----------+
        v         v
   host firewall / routes
   svm_ssh · svm_dns · svm_files · svm_tools
```

Mapping states: RECORDED -> INSTALLED -> LOCAL_VERIFIED -> EXTERNAL_VERIFIED
