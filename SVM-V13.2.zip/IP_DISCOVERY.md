# IP Discovery — SVM V14 (AnkitCoder)

## What it does

On install / `!autoconfig` / `!autopool scan`:

1. Read host addresses via `ip -j address`
2. Classify (private, public-candidate, CGNAT, loopback, …)
3. Merge with previous inventory (preserve manual notes)
4. Write **`ips.txt`** and **`ips.json`** atomically (with `.bak.*`)
5. Optionally soft-sync into IPAM DB **without** deleting ALLOCATED rows

## What it does **not** do

- Does not invent public IPv4 ownership
- Does not change firewall, routes, or SSH during discovery
- Observed egress IP (optional URL) is **not** ownership proof

## Files

- `svm_ip_discovery.py`
- `ips.txt` / `ips.json` (generated on host)
- Env: `SVM_IPS_TXT`, `SVM_IPS_JSON`, `SVM_EGRESS_CHECK_URL` (optional)

## Commands

```
!autoconfig
!autopool status|scan|sync|list
!autopool userping <vpsid>
!ipscan / !iplist / !ipstatus
```
