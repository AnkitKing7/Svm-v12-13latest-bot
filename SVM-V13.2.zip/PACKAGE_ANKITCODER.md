# SVM Advanced AI V13 — AnkitCoder Package

**Developer:** AnkitCoder  
**Version:** 13.0  
**Package:** SVM-Advanced-AI-V13-AnkitCoder.zip

## Modules included

| Module | Role |
|--------|------|
| `bot.py` | Discord bot + Flask WebSSH/Admin/FileManager |
| `svm12.py` | Payments, migrations, OS catalog, providers |
| `svm_ipam.py` | IPv4 IPAM lifecycle + /32 helpers |
| `svm_net.py` | nftables/iptables NAT backend |
| `svm_ssh.py` | SSH diagnose + Termius profiles |
| `svm_files.py` | SFTP list/upload/delete/rename |
| `svm_dns.py` | Hostname + DNS verify + Cloudflare adapter |
| `svm_tools.py` | Typed tool registry (honest counts) |
| `filemanager.html` | Browser file manager UI (`/filemanager`) |
| `webssh.html` | WebSSH terminal |
| `admin.html` | Admin panel |
| `install.sh` | Install / upgrade / doctor / test / rollback |
| `assets/*.svg|*.png` | Status cards |
| `tests/` | Unit + integration tests |

## Install

```bash
unzip SVM-Advanced-AI-V13-AnkitCoder.zip -d SVM-Advanced-V13
cd SVM-Advanced-V13
sudo bash install.sh upgrade
# or first install:
sudo bash install.sh
```

## Quick URLs (after install)

- WebSSH: `http://SERVER:5000/`
- File Manager: `http://SERVER:5000/filemanager`
- Admin: `http://SERVER:5000/admin`

## Discord

- `!filemanager <vps>` / `!fm`
- `!oslist` / `!oshealth`
- `!botinfo`
- `!askai …` (LocalAI)

Made by **AnkitCoder**
