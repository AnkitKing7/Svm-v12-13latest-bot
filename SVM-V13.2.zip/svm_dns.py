"""
SVM V13 — Hostname generation + DNS verification + optional Cloudflare adapter
Made by AnkitCoder.

Rules:
  - Never claim public DNS is live from a local /etc/hosts entry alone.
  - Verify with real DNS queries (system resolver / optional DoH).
  - Cloudflare adapter only mutates records when API token + zone are configured.
  - Hostname labels are validated (RFC-ish) and tenant-safe.
"""
from __future__ import annotations

import json
import logging
import os
import re
import socket
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional, Sequence, Tuple

logger = logging.getLogger("svm.dns")

LABEL_RE = re.compile(r"^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$", re.I)
HOSTNAME_TEMPLATE_DEFAULT = "vps-{id}"


@dataclass
class DNSConfig:
    domain_suffix: str = ""
    provider: str = ""  # "", "cloudflare", "none"
    api_token: str = ""
    zone_id: str = ""
    ttl: int = 300
    public_enabled: bool = False
    template: str = HOSTNAME_TEMPLATE_DEFAULT
    verify_timeout: float = 5.0

    @classmethod
    def from_env(cls) -> "DNSConfig":
        return cls(
            domain_suffix=(os.getenv("DNS_DOMAIN_SUFFIX") or "").strip().strip("."),
            provider=(os.getenv("DNS_PROVIDER") or "").strip().lower(),
            api_token=(os.getenv("DNS_API_TOKEN") or os.getenv("CLOUDFLARE_API_TOKEN") or "").strip(),
            zone_id=(os.getenv("DNS_ZONE_ID") or os.getenv("CLOUDFLARE_ZONE_ID") or "").strip(),
            ttl=max(60, int(os.getenv("DNS_TTL") or "300")),
            public_enabled=(os.getenv("DNS_PUBLIC_ENABLED") or "false").lower() in ("1", "true", "yes"),
            template=(os.getenv("HOSTNAME_TEMPLATE") or HOSTNAME_TEMPLATE_DEFAULT).strip() or HOSTNAME_TEMPLATE_DEFAULT,
        )


@dataclass
class DNSRecordResult:
    hostname: str
    rtype: str
    expected: str
    answers: List[str] = field(default_factory=list)
    matched: bool = False
    error: str = ""
    source: str = "system"  # system | doh | cloudflare

    def as_dict(self) -> Dict[str, Any]:
        return asdict(self)


def validate_label(label: str) -> bool:
    if not label or len(label) > 63:
        return False
    return bool(LABEL_RE.match(label))


def validate_fqdn(name: str) -> bool:
    name = (name or "").strip().rstrip(".").lower()
    if not name or len(name) > 253:
        return False
    parts = name.split(".")
    if len(parts) < 1:
        return False
    return all(validate_label(p) for p in parts)


def sanitize_id(raw: str) -> str:
    s = re.sub(r"[^a-zA-Z0-9-]+", "-", str(raw).strip().lower())
    s = re.sub(r"-+", "-", s).strip("-")
    return (s or "vps")[:48]


def generate_hostname(
    vps_id: str,
    *,
    template: Optional[str] = None,
    domain_suffix: Optional[str] = None,
    override: Optional[str] = None,
    cfg: Optional[DNSConfig] = None,
) -> str:
    """
    Build a stable hostname. If override is a valid FQDN/label, use it.
    Otherwise apply template with {id} and optional domain suffix.
    """
    cfg = cfg or DNSConfig.from_env()
    if override:
        o = override.strip().rstrip(".").lower()
        if "." in o and validate_fqdn(o):
            return o
        if validate_label(o):
            suffix = (domain_suffix if domain_suffix is not None else cfg.domain_suffix) or ""
            return f"{o}.{suffix}".rstrip(".") if suffix else o
        raise ValueError(f"Invalid hostname override: {override}")

    tpl = template or cfg.template or HOSTNAME_TEMPLATE_DEFAULT
    vid = sanitize_id(vps_id)
    try:
        label = tpl.format(id=vid, vps_id=vid)
    except Exception:
        label = f"vps-{vid}"
    label = sanitize_id(label)
    if not validate_label(label):
        label = f"vps-{vid}"[:63]
    suffix = (domain_suffix if domain_suffix is not None else cfg.domain_suffix) or ""
    if suffix:
        fqdn = f"{label}.{suffix.strip('.')}".lower()
        if not validate_fqdn(fqdn):
            raise ValueError(f"Generated FQDN invalid: {fqdn}")
        return fqdn
    return label


def resolve_a(hostname: str, timeout: float = 5.0) -> Tuple[List[str], str]:
    """Return (addresses, error). Uses system getaddrinfo — real OS resolver."""
    hostname = hostname.strip().rstrip(".")
    if not hostname:
        return [], "empty hostname"
    try:
        old = socket.getdefaulttimeout()
        socket.setdefaulttimeout(timeout)
        try:
            infos = socket.getaddrinfo(hostname, None, type=socket.SOCK_STREAM)
        finally:
            socket.setdefaulttimeout(old)
        addrs = sorted({i[4][0] for i in infos if i[4]})
        return addrs, ""
    except socket.gaierror as e:
        return [], f"NXDOMAIN/gaierror: {e}"
    except Exception as e:
        return [], str(e)


def verify_a_record(
    hostname: str,
    expected_ip: str,
    *,
    timeout: float = 5.0,
) -> DNSRecordResult:
    answers, err = resolve_a(hostname, timeout=timeout)
    matched = expected_ip in answers if expected_ip and answers else False
    return DNSRecordResult(
        hostname=hostname,
        rtype="A",
        expected=expected_ip,
        answers=answers,
        matched=matched,
        error=err,
        source="system",
    )


def verify_hostname_live(
    hostname: str,
    expected_ip: Optional[str] = None,
    *,
    cfg: Optional[DNSConfig] = None,
) -> Dict[str, Any]:
    """
    Public DNS verification report. Does NOT treat local hosts-file as proof of public DNS.
    """
    cfg = cfg or DNSConfig.from_env()
    if not validate_fqdn(hostname) and not validate_label(hostname):
        return {"ok": False, "error": "invalid hostname", "hostname": hostname}
    res = verify_a_record(hostname, expected_ip or "", timeout=cfg.verify_timeout)
    out = {
        "ok": bool(res.matched) if expected_ip else bool(res.answers),
        "hostname": hostname,
        "expected_ip": expected_ip,
        "answers": res.answers,
        "matched": res.matched,
        "error": res.error,
        "public_enabled": cfg.public_enabled,
        "note": (
            "Public DNS claimed only when query returns expected A record."
            if expected_ip
            else "Resolved addresses listed; no expected IP provided so match not required."
        ),
    }
    if not cfg.public_enabled and cfg.provider:
        out["note"] += " DNS_PUBLIC_ENABLED is false — mutations disabled."
    return out


# ---------------------------------------------------------------------------
# Cloudflare adapter (optional)
# ---------------------------------------------------------------------------

class CloudflareError(RuntimeError):
    pass


class CloudflareDNS:
    """Minimal Cloudflare DNS API client. Requires API token with Zone.DNS edit."""

    API = "https://api.cloudflare.com/client/v4"

    def __init__(self, token: str, zone_id: str, timeout: float = 15.0):
        if not token or not zone_id:
            raise CloudflareError("CLOUDFLARE token and zone_id required")
        self.token = token
        self.zone_id = zone_id
        self.timeout = timeout

    def _request(self, method: str, path: str, body: Optional[dict] = None) -> dict:
        url = f"{self.API}{path}"
        data = None if body is None else json.dumps(body).encode()
        req = urllib.request.Request(
            url,
            data=data,
            method=method,
            headers={
                "Authorization": f"Bearer {self.token}",
                "Content-Type": "application/json",
                "User-Agent": "SVM-Advanced-AI-V13/AnkitCoder",
            },
        )
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                raw = resp.read().decode()
                return json.loads(raw or "{}")
        except urllib.error.HTTPError as e:
            detail = e.read().decode(errors="replace")[:300]
            raise CloudflareError(f"HTTP {e.code}: {detail}") from e
        except Exception as e:
            raise CloudflareError(str(e)) from e

    def list_a_records(self, name: str) -> List[dict]:
        name = name.rstrip(".")
        q = urllib.parse.quote if False else __import__("urllib.parse").parse.quote
        path = f"/zones/{self.zone_id}/dns_records?type=A&name={q(name)}"
        data = self._request("GET", path)
        if not data.get("success"):
            raise CloudflareError(str(data.get("errors") or data))
        return list(data.get("result") or [])

    def upsert_a(self, name: str, ip: str, ttl: int = 300, proxied: bool = False) -> dict:
        name = name.rstrip(".")
        existing = self.list_a_records(name)
        payload = {"type": "A", "name": name, "content": ip, "ttl": max(60, int(ttl)), "proxied": bool(proxied)}
        if existing:
            rid = existing[0]["id"]
            data = self._request("PUT", f"/zones/{self.zone_id}/dns_records/{rid}", payload)
        else:
            data = self._request("POST", f"/zones/{self.zone_id}/dns_records", payload)
        if not data.get("success"):
            raise CloudflareError(str(data.get("errors") or data))
        return data.get("result") or {}

    def delete_a(self, name: str) -> int:
        name = name.rstrip(".")
        existing = self.list_a_records(name)
        n = 0
        for rec in existing:
            data = self._request("DELETE", f"/zones/{self.zone_id}/dns_records/{rec['id']}")
            if data.get("success"):
                n += 1
        return n


def ensure_public_a(
    hostname: str,
    ipv4: str,
    *,
    cfg: Optional[DNSConfig] = None,
    dry_run: bool = True,
) -> Dict[str, Any]:
    """
    Create/update public A record when provider configured and public_enabled.
    Always returns verification attempt result.
    """
    cfg = cfg or DNSConfig.from_env()
    out: Dict[str, Any] = {
        "hostname": hostname,
        "ipv4": ipv4,
        "dry_run": dry_run,
        "mutated": False,
        "provider": cfg.provider or "none",
    }
    if not cfg.public_enabled:
        out["ok"] = False
        out["error"] = "DNS_PUBLIC_ENABLED is false"
        return out
    if cfg.provider not in ("cloudflare",):
        out["ok"] = False
        out["error"] = f"No mutating adapter for provider={cfg.provider!r}"
        return out
    if dry_run:
        out["ok"] = True
        out["note"] = "DRY-RUN: would upsert Cloudflare A record"
        return out
    try:
        cf = CloudflareDNS(cfg.api_token, cfg.zone_id)
        rec = cf.upsert_a(hostname, ipv4, ttl=cfg.ttl)
        out["mutated"] = True
        out["record_id"] = rec.get("id")
        # verify via system resolver (may lag on TTL/propagation)
        time.sleep(0.5)
        ver = verify_hostname_live(hostname, ipv4, cfg=cfg)
        out["verify"] = ver
        out["ok"] = True  # mutation succeeded; verify may still lag
        if not ver.get("matched"):
            out["note"] = "Record written; resolver not yet matching (propagation)"
        return out
    except CloudflareError as e:
        out["ok"] = False
        out["error"] = str(e)
        return out
