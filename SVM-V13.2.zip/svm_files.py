"""
SVM V13 — SFTP file manager backend
Made by AnkitCoder.

Safe SFTP operations over Paramiko. Never logs passwords or private keys.
All paths are normalized; path traversal (..) is rejected.
"""
from __future__ import annotations

import io
import logging
import os
import posixpath
import stat
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger("svm.files")

MAX_UPLOAD_BYTES = 50 * 1024 * 1024  # 50 MiB per file
MAX_LIST_ENTRIES = 500
MAX_READ_PREVIEW = 512 * 1024  # 512 KiB text preview


@dataclass
class FMConnection:
    host: str
    port: int
    username: str
    password: Optional[str] = None
    key_filename: Optional[str] = None


def _safe_remote_path(path: str, base: str = "/") -> str:
    """Join and normalize; reject escape above base."""
    path = (path or "/").replace("\\", "/")
    if not path.startswith("/"):
        path = posixpath.join(base, path)
    norm = posixpath.normpath(path)
    if not norm.startswith("/"):
        norm = "/" + norm
    # block null bytes
    if "\x00" in norm:
        raise ValueError("Invalid path")
    return norm


def open_sftp(conn: FMConnection, timeout: int = 30):
    import paramiko
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    kwargs: Dict[str, Any] = {
        "hostname": conn.host,
        "port": int(conn.port),
        "username": conn.username,
        "timeout": timeout,
        "allow_agent": False,
        "look_for_keys": False,
    }
    if conn.key_filename:
        kwargs["key_filename"] = conn.key_filename
    elif conn.password is not None:
        kwargs["password"] = conn.password
    else:
        raise ValueError("password or key_filename required")
    client.connect(**kwargs)
    sftp = client.open_sftp()
    return client, sftp


def list_dir(conn: FMConnection, path: str = "/") -> Dict[str, Any]:
    path = _safe_remote_path(path)
    client, sftp = open_sftp(conn)
    try:
        entries = []
        for attr in sftp.listdir_attr(path)[:MAX_LIST_ENTRIES]:
            mode = attr.st_mode or 0
            is_dir = stat.S_ISDIR(mode)
            is_lnk = stat.S_ISLNK(mode)
            entries.append({
                "name": attr.filename,
                "path": posixpath.join(path, attr.filename),
                "size": int(attr.st_size or 0),
                "mtime": int(attr.st_mtime or 0),
                "mode": stat.filemode(mode) if mode else "?",
                "is_dir": bool(is_dir),
                "is_link": bool(is_lnk),
            })
        entries.sort(key=lambda e: (not e["is_dir"], e["name"].lower()))
        return {"ok": True, "path": path, "entries": entries, "count": len(entries)}
    finally:
        try:
            sftp.close()
        except Exception:
            pass
        try:
            client.close()
        except Exception:
            pass


def mkdir(conn: FMConnection, path: str) -> Dict[str, Any]:
    path = _safe_remote_path(path)
    if path in ("/", ""):
        return {"ok": False, "error": "Cannot create root"}
    client, sftp = open_sftp(conn)
    try:
        sftp.mkdir(path)
        return {"ok": True, "path": path}
    except OSError as e:
        return {"ok": False, "error": str(e)}
    finally:
        sftp.close()
        client.close()


def rename(conn: FMConnection, src: str, dst: str) -> Dict[str, Any]:
    src = _safe_remote_path(src)
    dst = _safe_remote_path(dst)
    client, sftp = open_sftp(conn)
    try:
        sftp.rename(src, dst)
        return {"ok": True, "src": src, "dst": dst}
    except OSError as e:
        return {"ok": False, "error": str(e)}
    finally:
        sftp.close()
        client.close()


def delete(conn: FMConnection, path: str, recursive: bool = False) -> Dict[str, Any]:
    path = _safe_remote_path(path)
    if path in ("/", ""):
        return {"ok": False, "error": "Refusing to delete root"}
    client, sftp = open_sftp(conn)
    try:
        try:
            st = sftp.stat(path)
        except FileNotFoundError:
            return {"ok": False, "error": "Not found"}
        if stat.S_ISDIR(st.st_mode or 0):
            if not recursive:
                return {"ok": False, "error": "Path is a directory; set recursive=true"}
            _rmtree(sftp, path)
        else:
            sftp.remove(path)
        return {"ok": True, "path": path}
    except OSError as e:
        return {"ok": False, "error": str(e)}
    finally:
        sftp.close()
        client.close()


def _rmtree(sftp, path: str) -> None:
    for attr in sftp.listdir_attr(path):
        p = posixpath.join(path, attr.filename)
        if stat.S_ISDIR(attr.st_mode or 0):
            _rmtree(sftp, p)
        else:
            sftp.remove(p)
    sftp.rmdir(path)


def upload(conn: FMConnection, remote_path: str, data: bytes) -> Dict[str, Any]:
    if len(data) > MAX_UPLOAD_BYTES:
        return {"ok": False, "error": f"File exceeds {MAX_UPLOAD_BYTES} bytes limit"}
    remote_path = _safe_remote_path(remote_path)
    client, sftp = open_sftp(conn)
    try:
        with sftp.file(remote_path, "wb") as f:
            f.write(data)
        return {"ok": True, "path": remote_path, "size": len(data)}
    except OSError as e:
        return {"ok": False, "error": str(e)}
    finally:
        sftp.close()
        client.close()


def download(conn: FMConnection, remote_path: str, max_bytes: int = MAX_UPLOAD_BYTES
             ) -> Tuple[bool, bytes, str]:
    remote_path = _safe_remote_path(remote_path)
    client, sftp = open_sftp(conn)
    try:
        st = sftp.stat(remote_path)
        if stat.S_ISDIR(st.st_mode or 0):
            return False, b"", "Path is a directory"
        size = int(st.st_size or 0)
        if size > max_bytes:
            return False, b"", f"File too large ({size} bytes)"
        with sftp.file(remote_path, "rb") as f:
            data = f.read(max_bytes + 1)
        if len(data) > max_bytes:
            return False, b"", "File too large"
        return True, data, remote_path
    except OSError as e:
        return False, b"", str(e)
    finally:
        sftp.close()
        client.close()
