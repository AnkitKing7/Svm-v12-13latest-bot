"""
SVM Advanced AI V13 — Unified IPv4/IPv6 IPAM Service
Made by AnkitCoder.

Provides:
  - CIDR/pool validation, usable-range calculation, overlap detection
  - Lifecycle states: available, reserved, assigned, configuring, active,
    failed, releasing, quarantined
  - Transactional allocation with uniqueness constraints
  - Mapping modes: record-only, routed, 1:1 NAT, port-forward
  - Drift detection between DB intent and host state (reported, not silent)
  - Safe concurrent allocation (DB-level check-and-set under lock)

This module is intentionally pure-Python + SQLite; host networking backends
live in svm_net.py.  Never claims a mapping is ACTIVE unless the backend
reports successful installation and optional verification.
"""
from __future__ import annotations

import ipaddress
import itertools
import logging
import sqlite3
import threading
import time
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional, Sequence, Tuple

logger = logging.getLogger("svm.ipam")

# ---------------------------------------------------------------------------
# Constants & enums
# ---------------------------------------------------------------------------

IPAM_SCHEMA_VERSION = 13001
DEFAULT_POOL_MAX_ADDRS = 4096
RESERVED_HOST_PORTS = frozenset(range(1, 1024)) | {5000, 8080, 8443, 8787}


class AddrStatus(str, Enum):
    AVAILABLE = "available"
    RESERVED = "reserved"
    ASSIGNED = "assigned"          # allocated to a VM, not yet programmed
    CONFIGURING = "configuring"    # backend applying rules
    ACTIVE = "active"              # backend verified
    FAILED = "failed"
    RELEASING = "releasing"
    QUARANTINED = "quarantined"


class BindMode(str, Enum):
    RECORD = "record"       # DB bookkeeping only — never claim public reachability
    ROUTED = "routed"       # provider routes public IP to host; host routes to VM
    NAT = "nat"             # 1:1 DNAT/SNAT
    PORTFWD = "portfwd"     # host public IP + TCP/UDP port forwards only
    BRIDGED = "bridged"     # LXD/Incus static address on bridge (legacy)


class Health(str, Enum):
    UNKNOWN = "unknown"
    RECORDED = "recorded"   # DB only
    INSTALLED = "installed" # rules present
    VERIFIED = "verified"   # external or isolated check passed
    DRIFT = "drift"         # DB says active, host missing rules
    FAILED = "failed"


def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


# ---------------------------------------------------------------------------
# Pure calculation helpers (unit-testable, no DB)
# ---------------------------------------------------------------------------

def validate_cidr(cidr: str) -> ipaddress.IPv4Network | ipaddress.IPv6Network:
    net = ipaddress.ip_network(str(cidr).strip(), strict=False)
    return net


def network_info(cidr: str) -> Dict[str, Any]:
    net = validate_cidr(cidr)
    if net.version == 4:
        hosts = list(net.hosts()) if net.prefixlen < 31 else list(net)
        return {
            "version": 4,
            "network": str(net.network_address),
            "broadcast": str(net.broadcast_address),
            "netmask": str(net.netmask),
            "prefixlen": net.prefixlen,
            "num_addresses": net.num_addresses,
            "usable": [str(h) for h in hosts],
            "usable_count": len(hosts),
            "is_private": net.is_private,
            "is_global": net.is_global,
            "is_link_local": net.is_link_local,
            "is_loopback": net.is_loopback,
            "is_multicast": net.is_multicast,
        }
    # IPv6
    usable = list(itertools.islice(net.hosts(), DEFAULT_POOL_MAX_ADDRS + 1))
    truncated = len(usable) > DEFAULT_POOL_MAX_ADDRS
    if truncated:
        usable = usable[:DEFAULT_POOL_MAX_ADDRS]
    return {
        "version": 6,
        "network": str(net.network_address),
        "broadcast": None,
        "netmask": str(net.netmask),
        "prefixlen": net.prefixlen,
        "num_addresses": net.num_addresses,
        "usable": [str(h) for h in usable],
        "usable_count": len(usable),
        "truncated": truncated,
        "is_private": net.is_private,
        "is_global": net.is_global,
        "is_link_local": net.is_link_local,
        "is_loopback": net.is_loopback,
        "is_multicast": net.is_multicast,
    }


def expand_usable(cidr: str, limit: int = DEFAULT_POOL_MAX_ADDRS,
                  exclude: Optional[Sequence[str]] = None,
                  reserve_first: int = 0) -> Tuple[Any, List[str], bool]:
    """Return (network, usable_host_list, truncated)."""
    info = network_info(cidr)
    net = validate_cidr(cidr)
    usable = list(info["usable"])
    truncated = bool(info.get("truncated"))
    if len(usable) > limit:
        usable = usable[:limit]
        truncated = True
    excl = set(exclude or [])
    out = []
    for i, a in enumerate(usable):
        if a in excl:
            continue
        out.append(a)
    return net, out, truncated


def pools_overlap(cidr_a: str, cidr_b: str) -> bool:
    a = validate_cidr(cidr_a)
    b = validate_cidr(cidr_b)
    return a.overlaps(b)


def is_valid_hostname_label(label: str) -> bool:
    if not label or len(label) > 63:
        return False
    return bool(__import__("re").match(r"^[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?$", label))


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass
class Pool:
    id: int
    name: str
    cidr: str
    version: int
    gateway: Optional[str] = None
    node_id: Optional[int] = None
    enabled: bool = True
    created_at: str = ""
    notes: str = ""


@dataclass
class AddressRecord:
    id: int
    address: str
    version: int
    status: str
    pool_id: Optional[int] = None
    node_id: Optional[int] = None
    vps_id: Optional[str] = None
    container_name: Optional[str] = None
    bind_mode: Optional[str] = None
    private_ip: Optional[str] = None
    public_ip: Optional[str] = None
    prefix: Optional[int] = None
    gateway: Optional[str] = None
    host_interface: Optional[str] = None
    bridge: Optional[str] = None
    protocol: Optional[str] = None
    ports: Optional[str] = None          # JSON list or "22,80"
    rule_handles: Optional[str] = None   # backend-specific handles/comments
    health: str = Health.UNKNOWN.value
    health_detail: str = ""
    created_at: str = ""
    updated_at: str = ""
    notes: str = ""


# ---------------------------------------------------------------------------
# IPAM service (DB-backed)
# ---------------------------------------------------------------------------

class IPAMService:
    """
    Database-backed IPAM.  Caller supplies a connection factory that returns
    an open sqlite3 connection (row_factory=sqlite3.Row recommended).
    All mutating methods use an exclusive lock + transactional check-and-set
    so concurrent allocations cannot double-assign the same address.
    """

    def __init__(self, get_conn, lock: Optional[threading.Lock] = None,
                 pool_max: int = DEFAULT_POOL_MAX_ADDRS):
        self._get_conn = get_conn
        self._lock = lock or threading.Lock()
        self.pool_max = pool_max

    # -- schema -------------------------------------------------------------

    def ensure_schema(self) -> None:
        with self._lock:
            conn = self._get_conn()
            try:
                conn.executescript("""
                CREATE TABLE IF NOT EXISTS svm_schema_migrations (
                    id INTEGER PRIMARY KEY,
                    name TEXT NOT NULL,
                    applied_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS svm_ip_pools (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL UNIQUE,
                    cidr TEXT NOT NULL,
                    version INTEGER NOT NULL,
                    gateway TEXT,
                    node_id INTEGER,
                    enabled INTEGER NOT NULL DEFAULT 1,
                    notes TEXT DEFAULT '',
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS svm_ipam (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    address TEXT NOT NULL,
                    version INTEGER NOT NULL,
                    status TEXT NOT NULL DEFAULT 'available',
                    pool_id INTEGER,
                    node_id INTEGER,
                    vps_id TEXT,
                    container_name TEXT,
                    bind_mode TEXT,
                    private_ip TEXT,
                    public_ip TEXT,
                    prefix INTEGER,
                    gateway TEXT,
                    host_interface TEXT,
                    bridge TEXT,
                    protocol TEXT,
                    ports TEXT,
                    rule_handles TEXT,
                    health TEXT DEFAULT 'unknown',
                    health_detail TEXT DEFAULT '',
                    notes TEXT DEFAULT '',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    UNIQUE(address, version)
                );
                CREATE INDEX IF NOT EXISTS idx_ipam_status ON svm_ipam(status);
                CREATE INDEX IF NOT EXISTS idx_ipam_pool ON svm_ipam(pool_id);
                CREATE INDEX IF NOT EXISTS idx_ipam_container ON svm_ipam(container_name);
                CREATE INDEX IF NOT EXISTS idx_ipam_node ON svm_ipam(node_id);
                """)
                # additive columns for older DBs
                for col, ddl in (
                    ("private_ip", "TEXT"),
                    ("public_ip", "TEXT"),
                    ("prefix", "INTEGER"),
                    ("gateway", "TEXT"),
                    ("host_interface", "TEXT"),
                    ("bridge", "TEXT"),
                    ("protocol", "TEXT"),
                    ("ports", "TEXT"),
                    ("rule_handles", "TEXT"),
                    ("health", "TEXT DEFAULT 'unknown'"),
                    ("health_detail", "TEXT DEFAULT ''"),
                    ("notes", "TEXT DEFAULT ''"),
                ):
                    try:
                        conn.execute(f"ALTER TABLE svm_ipam ADD COLUMN {col} {ddl}")
                    except sqlite3.OperationalError:
                        pass
                try:
                    conn.execute("ALTER TABLE svm_ip_pools ADD COLUMN notes TEXT DEFAULT ''")
                except sqlite3.OperationalError:
                    pass
                # mark migration
                cur = conn.execute(
                    "SELECT 1 FROM svm_schema_migrations WHERE id=?", (IPAM_SCHEMA_VERSION,))
                if not cur.fetchone():
                    conn.execute(
                        "INSERT INTO svm_schema_migrations(id, name, applied_at) VALUES(?,?,?)",
                        (IPAM_SCHEMA_VERSION, "ipam_v13_lifecycle", _now()))
                conn.commit()
            finally:
                conn.close()

    # -- pool management ----------------------------------------------------

    def add_pool(self, name: str, cidr: str, gateway: Optional[str] = None,
                 node_id: Optional[int] = None, reserve_first: int = 0,
                 exclude: Optional[Sequence[str]] = None,
                 notes: str = "") -> Tuple[int, int, bool]:
        """Create pool and seed address rows. Returns (pool_id, addr_count, truncated)."""
        net, addrs, truncated = expand_usable(cidr, limit=self.pool_max, exclude=exclude)
        if gateway:
            gw = str(ipaddress.ip_address(gateway))
            if ipaddress.ip_address(gw) not in net:
                raise ValueError(f"Gateway {gw} is not inside {cidr}")
        else:
            gw = None
        # overlap check against existing pools
        with self._lock:
            conn = self._get_conn()
            try:
                existing = conn.execute("SELECT name, cidr FROM svm_ip_pools").fetchall()
                for row in existing:
                    if pools_overlap(cidr, row["cidr"]):
                        raise ValueError(
                            f"CIDR {cidr} overlaps existing pool '{row['name']}' ({row['cidr']})")
                now = _now()
                cur = conn.execute(
                    "INSERT INTO svm_ip_pools(name,cidr,version,gateway,node_id,enabled,notes,created_at) "
                    "VALUES(?,?,?,?,?,1,?,?)",
                    (name, str(net), net.version, gw, node_id, notes, now))
                pool_id = cur.lastrowid
                rows = []
                for i, a in enumerate(addrs):
                    if gw and a == gw:
                        continue
                    status = AddrStatus.RESERVED.value if i < reserve_first else AddrStatus.AVAILABLE.value
                    rows.append((a, net.version, status, node_id, pool_id, now, now))
                conn.executemany(
                    "INSERT OR IGNORE INTO svm_ipam(address,version,status,node_id,pool_id,created_at,updated_at) "
                    "VALUES(?,?,?,?,?,?,?)", rows)
                conn.commit()
                return pool_id, len(rows), truncated
            except Exception:
                conn.rollback()
                raise
            finally:
                conn.close()

    def list_pools(self) -> List[Dict[str, Any]]:
        conn = self._get_conn()
        try:
            rows = conn.execute(
                "SELECT p.*, "
                "COALESCE(SUM(a.status='available'),0) AS free, "
                "COALESCE(SUM(a.status IN ('assigned','configuring','active')),0) AS used, "
                "COUNT(a.id) AS total "
                "FROM svm_ip_pools p LEFT JOIN svm_ipam a ON a.pool_id=p.id "
                "GROUP BY p.id ORDER BY p.id").fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    def get_pool(self, name_or_id) -> Optional[Dict[str, Any]]:
        conn = self._get_conn()
        try:
            if isinstance(name_or_id, int) or str(name_or_id).isdigit():
                row = conn.execute("SELECT * FROM svm_ip_pools WHERE id=?", (int(name_or_id),)).fetchone()
            else:
                row = conn.execute("SELECT * FROM svm_ip_pools WHERE name=?", (name_or_id,)).fetchone()
            return dict(row) if row else None
        finally:
            conn.close()

    # -- allocation ---------------------------------------------------------

    def allocate(self, container: str, vps_id: Optional[str] = None,
                 node_id: Optional[int] = None, version: int = 4,
                 pool: Optional[str] = None,
                 bind_mode: str = BindMode.RECORD.value,
                 private_ip: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """
        Atomically claim one available address.
        Returns the updated row dict or None if exhausted.
        Status becomes 'assigned' (not yet active on host).
        """
        if bind_mode not in {m.value for m in BindMode}:
            raise ValueError(f"Unsupported bind_mode: {bind_mode}")
        with self._lock:
            conn = self._get_conn()
            try:
                sql = ("SELECT a.* FROM svm_ipam a LEFT JOIN svm_ip_pools p ON p.id=a.pool_id "
                       "WHERE a.status='available' AND a.version=? AND (p.id IS NULL OR p.enabled=1)")
                params: list = [version]
                if pool:
                    sql += " AND p.name=?"
                    params.append(pool)
                if node_id is not None:
                    sql += " AND (a.node_id IS NULL OR a.node_id=?)"
                    params.append(node_id)
                sql += " ORDER BY a.id LIMIT 1"
                row = conn.execute(sql, params).fetchone()
                if not row:
                    return None
                now = _now()
                cur = conn.execute(
                    "UPDATE svm_ipam SET status=?, vps_id=?, container_name=?, bind_mode=?, "
                    "private_ip=?, health=?, updated_at=? "
                    "WHERE id=? AND status='available'",
                    (AddrStatus.ASSIGNED.value, vps_id, container, bind_mode,
                     private_ip, Health.RECORDED.value, now, row["id"]))
                if cur.rowcount != 1:
                    conn.rollback()
                    return None
                conn.commit()
                out = dict(row)
                out.update(status=AddrStatus.ASSIGNED.value, container_name=container,
                           bind_mode=bind_mode, private_ip=private_ip,
                           health=Health.RECORDED.value, updated_at=now)
                return out
            finally:
                conn.close()

    def set_status(self, address: str, status: str, *, health: Optional[str] = None,
                   health_detail: str = "", rule_handles: Optional[str] = None,
                   private_ip: Optional[str] = None) -> bool:
        with self._lock:
            conn = self._get_conn()
            try:
                fields = ["status=?", "updated_at=?"]
                params: list = [status, _now()]
                if health is not None:
                    fields.append("health=?")
                    params.append(health)
                if health_detail:
                    fields.append("health_detail=?")
                    params.append(health_detail[:500])
                if rule_handles is not None:
                    fields.append("rule_handles=?")
                    params.append(rule_handles)
                if private_ip is not None:
                    fields.append("private_ip=?")
                    params.append(private_ip)
                params.append(address)
                cur = conn.execute(
                    f"UPDATE svm_ipam SET {', '.join(fields)} WHERE address=?", params)
                conn.commit()
                return cur.rowcount == 1
            finally:
                conn.close()

    def release(self, address: str, quarantine: bool = False) -> bool:
        status = AddrStatus.QUARANTINED.value if quarantine else AddrStatus.AVAILABLE.value
        with self._lock:
            conn = self._get_conn()
            try:
                cur = conn.execute(
                    "UPDATE svm_ipam SET status=?, vps_id=NULL, container_name=NULL, bind_mode=NULL, "
                    "private_ip=NULL, public_ip=NULL, rule_handles=NULL, health=?, health_detail='', "
                    "updated_at=? WHERE address=?",
                    (status, Health.UNKNOWN.value, _now(), address))
                conn.commit()
                return cur.rowcount == 1
            finally:
                conn.close()

    def reserve(self, address: str, note: str = "") -> bool:
        with self._lock:
            conn = self._get_conn()
            try:
                cur = conn.execute(
                    "UPDATE svm_ipam SET status=?, notes=?, updated_at=? "
                    "WHERE address=? AND status='available'",
                    (AddrStatus.RESERVED.value, note[:200], _now(), address))
                conn.commit()
                return cur.rowcount == 1
            finally:
                conn.close()

    def find(self, address: Optional[str] = None, container: Optional[str] = None,
             vps_id: Optional[str] = None) -> List[Dict[str, Any]]:
        conn = self._get_conn()
        try:
            sql = "SELECT * FROM svm_ipam WHERE 1=1"
            params: list = []
            if address:
                sql += " AND address=?"
                params.append(address)
            if container:
                sql += " AND container_name=?"
                params.append(container)
            if vps_id:
                sql += " AND vps_id=?"
                params.append(vps_id)
            rows = conn.execute(sql + " ORDER BY id", params).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    def inventory(self, pool: Optional[str] = None) -> Dict[str, Any]:
        conn = self._get_conn()
        try:
            by_status: Dict[str, int] = {}
            sql = "SELECT status, COUNT(*) AS c FROM svm_ipam"
            params: list = []
            if pool:
                sql += " WHERE pool_id=(SELECT id FROM svm_ip_pools WHERE name=?)"
                params.append(pool)
            sql += " GROUP BY status"
            for r in conn.execute(sql, params):
                by_status[r["status"]] = r["c"]
            return {"by_status": by_status, "total": sum(by_status.values())}
        finally:
            conn.close()

    def mappings_for_reconcile(self, statuses: Optional[Sequence[str]] = None) -> List[Dict[str, Any]]:
        statuses = statuses or [AddrStatus.ASSIGNED.value, AddrStatus.CONFIGURING.value,
                                AddrStatus.ACTIVE.value, AddrStatus.FAILED.value]
        placeholders = ",".join("?" * len(statuses))
        conn = self._get_conn()
        try:
            rows = conn.execute(
                f"SELECT * FROM svm_ipam WHERE status IN ({placeholders}) ORDER BY id",
                list(statuses)).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()


# ---------------------------------------------------------------------------
# Convenience: detect whether an address looks publicly routable (heuristic)
# ---------------------------------------------------------------------------

def address_publicness(addr: str) -> str:
    """Return 'public', 'private', 'cgnat', 'link-local', 'loopback', 'other'."""
    try:
        ip = ipaddress.ip_address(addr)
    except ValueError:
        return "invalid"
    if ip.is_loopback:
        return "loopback"
    if ip.is_link_local:
        return "link-local"
    if ip.version == 4:
        # CGNAT 100.64.0.0/10
        if ipaddress.ip_address(addr) in ipaddress.ip_network("100.64.0.0/10"):
            return "cgnat"
        if ip.is_private:
            return "private"
        if ip.is_global:
            return "public"
    else:
        if ip.is_private or ip.is_site_local:
            return "private"
        if ip.is_global:
            return "public"
    return "other"


def is_point_to_point_mask(netmask_or_prefix) -> bool:
    """True for /32 or 255.255.255.255 — common on hypervisor-NAT (SRN-style) hosts."""
    s = str(netmask_or_prefix).strip()
    if s in ("32", "/32", "255.255.255.255"):
        return True
    try:
        if int(s) == 32:
            return True
    except ValueError:
        pass
    return False


def recommended_bind_mode_for_host(public_addrs: list, default_gw: str = "") -> str:
    """
    Heuristic for SRN-style single public/private IP with /32 or private-only NIC.
    Returns portfwd|nat|record recommendation — never claims success by itself.
    """
    if not public_addrs:
        return "record"
    if len(public_addrs) == 1:
        return "portfwd"
    return "nat"
