"""
SVM V14 — Topology-aware public/private IPv4 mapping engine (modes A–E)
Made by AnkitCoder.

Modes:
  A portfwd  — shared public IP + TCP/UDP port → private:port
  B nat      — 1:1 DNAT/SNAT when public IP owned / authorized
  C routed   — provider-routed (requires topology confirm; no invented gateways)
  D wireguard— optional tunnel config generation (not public IPv4)
  E record   — DB/intent only

A mapping is never EXTERNAL_VERIFIED from DB or localhost alone.
"""
from __future__ import annotations

import logging
import secrets
import time
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional, Tuple

from svm_topology import (
    TopologyClass, MapVerifyState, detect_capabilities, classify_ipv4, redact_secrets,
)

logger = logging.getLogger("svm.map")


@dataclass
class MappingRequest:
    mode: str  # portfwd|nat|routed|wireguard|record
    public_ip: str = ""
    private_ip: str = ""
    public_port: Optional[int] = None
    private_port: Optional[int] = None
    protocol: str = "tcp"  # tcp|udp|both
    vps_id: str = ""
    container: str = ""
    node_id: Optional[int] = None
    tag: str = ""
    operator_confirmed: bool = False
    dry_run: bool = True
    topology_override: str = ""


@dataclass
class MappingResult:
    ok: bool
    mode: str
    state: str = MapVerifyState.UNKNOWN.value
    operation_id: str = ""
    detail: str = ""
    preview: List[str] = field(default_factory=list)
    handles: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    topology: str = ""
    rolled_back: bool = False

    def as_dict(self) -> Dict[str, Any]:
        return asdict(self)


def _opid() -> str:
    return f"map-{int(time.time())}-{secrets.token_hex(4)}"


def validate_request(req: MappingRequest) -> List[str]:
    errs = []
    mode = (req.mode or "").lower().strip()
    if mode not in ("portfwd", "nat", "routed", "wireguard", "record"):
        errs.append(f"unsupported mode: {req.mode}")
    proto = (req.protocol or "tcp").lower()
    if proto not in ("tcp", "udp", "both"):
        errs.append("protocol must be tcp|udp|both")
    if mode == "portfwd":
        if not req.public_ip or not req.private_ip:
            errs.append("portfwd requires public_ip and private_ip")
        if not req.public_port or not req.private_port:
            errs.append("portfwd requires public_port and private_port")
        for p in (req.public_port, req.private_port):
            if p is not None and not (1 <= int(p) <= 65535):
                errs.append(f"invalid port: {p}")
    if mode == "nat":
        if not req.public_ip or not req.private_ip:
            errs.append("nat requires public_ip and private_ip")
        if classify_ipv4(req.public_ip) not in ("public", "private"):  # private rare but allowed if owned
            if classify_ipv4(req.public_ip) == "invalid":
                errs.append("invalid public_ip")
    if mode == "routed" and not req.operator_confirmed:
        errs.append("routed mode requires operator_confirmed=True and documented provider routing")
    if mode in ("nat", "routed", "portfwd", "wireguard") and not req.dry_run and not req.operator_confirmed:
        errs.append("live apply requires operator_confirmed=True")
    return errs


def preview_mapping(req: MappingRequest) -> MappingResult:
    op = _opid()
    errs = validate_request(req)
    cap = detect_capabilities(operator_topology=req.topology_override)
    res = MappingResult(ok=not errs, mode=req.mode, operation_id=op, topology=cap.topology, errors=errs)
    if errs:
        res.state = MapVerifyState.FAILED.value
        res.detail = "; ".join(errs)
        return res

    mode = req.mode.lower()
    if mode not in cap.supported_modes and mode != "record":
        # Dry-run previews still allowed so operators can plan before enabling backends
        if not req.dry_run:
            res.ok = False
            res.errors.append(
                f"mode {mode} not in supported_modes {cap.supported_modes} for topology {cap.topology}"
            )
            res.state = MapVerifyState.FAILED.value
            res.detail = res.errors[-1]
            return res
        res.errors.append(
            f"warning: mode {mode} not currently supported on this host "
            f"({cap.topology}/{cap.backend}); dry-run preview only"
        )

    if mode == "record":
        res.state = MapVerifyState.RECORDED.value
        res.detail = "record-only; no host networking changes"
        res.preview = [f"RECORD {req.public_ip or '-'} -> {req.private_ip or '-'} vps={req.vps_id}"]
        return res

    if mode == "portfwd":
        protos = ["tcp", "udp"] if req.protocol == "both" else [req.protocol]
        for pr in protos:
            res.preview.append(
                f"DNAT {req.public_ip}:{req.public_port}/{pr} -> {req.private_ip}:{req.private_port} "
                f"(tag=SVM-V14:{req.tag or req.container or op})"
            )
        res.state = MapVerifyState.RECORDED.value
        res.detail = "DRY-RUN preview" if req.dry_run else "preview before apply"
        return res

    if mode == "nat":
        res.preview.append(f"1:1 DNAT/SNAT {req.public_ip} <-> {req.private_ip}")
        res.detail = "Requires public address ownership or provider-authorized routed config"
        res.state = MapVerifyState.RECORDED.value
        return res

    if mode == "routed":
        res.preview.append(
            "ROUTED mode: no automatic gateway/MAC invention; operator must supply verified topology"
        )
        res.detail = "Blocked auto-apply without verified provider route documentation"
        res.state = MapVerifyState.RECORDED.value
        res.ok = False
        res.errors.append("routed auto-programming disabled until topology prerequisites are verified")
        return res

    if mode == "wireguard":
        res.preview.append("Generate WireGuard peer config (keys must be created locally; never logged)")
        res.detail = "Tunnel is NOT a public IPv4 assignment"
        res.state = MapVerifyState.RECORDED.value
        return res

    res.ok = False
    res.detail = "unknown mode"
    return res


def apply_mapping(req: MappingRequest) -> MappingResult:
    """Apply or dry-run. Uses svm_net for portfwd/nat when available."""
    prev = preview_mapping(req)
    if not prev.ok and req.mode.lower() not in ("record",):
        # routed returns ok=False by design in preview
        if req.mode.lower() == "routed":
            return prev
        if prev.errors:
            return prev

    if req.mode.lower() == "record":
        prev.state = MapVerifyState.RECORDED.value
        prev.ok = True
        return prev

    if req.dry_run:
        prev.detail = (prev.detail or "") + " [dry-run: no host change]"
        prev.ok = True
        return prev

    if not req.operator_confirmed:
        prev.ok = False
        prev.errors.append("operator_confirmed required for live apply")
        prev.state = MapVerifyState.FAILED.value
        return prev

    mode = req.mode.lower()
    tag = req.tag or req.container or prev.operation_id

    if mode == "portfwd":
        try:
            from svm_net import apply_mapping as net_apply
        except ImportError:
            prev.ok = False
            prev.errors.append("svm_net unavailable")
            return prev
        protos = ["tcp", "udp"] if req.protocol == "both" else [req.protocol]
        all_handles: List[str] = []
        for pr in protos:
            ok, msg, handles = net_apply(
                "portfwd",
                public_ip=req.public_ip,
                private_ip=req.private_ip,
                public_port=int(req.public_port),
                private_port=int(req.private_port),
                proto=pr,
                tag=f"{tag}-{pr}",
                dry_run=False,
            )
            if not ok:
                prev.ok = False
                prev.errors.append(msg)
                prev.state = MapVerifyState.FAILED.value
                prev.detail = msg
                return prev
            all_handles.extend(handles)
        prev.handles = all_handles
        prev.state = MapVerifyState.INSTALLED.value
        prev.ok = True
        prev.detail = "rules installed; LOCAL_VERIFIED requires independent rule check"
        # local verify via owned rules
        try:
            from svm_net import verify_mapping_installed
            vok, vmsg = verify_mapping_installed("portfwd", f"{tag}-tcp")
            if vok:
                prev.state = MapVerifyState.LOCAL_VERIFIED.value
                prev.detail = vmsg
            else:
                prev.state = MapVerifyState.INSTALLED.value
                prev.detail = f"installed but verify: {vmsg}"
        except Exception as e:
            prev.detail = f"installed; verify error: {e}"
        return prev

    if mode == "nat":
        try:
            from svm_net import apply_mapping as net_apply
        except ImportError:
            prev.ok = False
            prev.errors.append("svm_net unavailable")
            return prev
        ok, msg, handles = net_apply(
            "nat",
            public_ip=req.public_ip,
            private_ip=req.private_ip,
            tag=tag,
            dry_run=False,
        )
        prev.ok = ok
        prev.handles = handles
        prev.detail = msg
        prev.state = MapVerifyState.LOCAL_VERIFIED.value if ok else MapVerifyState.FAILED.value
        return prev

    if mode == "wireguard":
        prev.ok = True
        prev.state = MapVerifyState.RECORDED.value
        prev.detail = (
            "WireGuard: generate keys with 'wg genkey' on the host; "
            "SVM does not store private keys. Tunnel ≠ public IPv4."
        )
        prev.preview.append("[Interface]\\nPrivateKey = <LOCAL_ONLY>\\nAddress = <allocated_tunnel_ip>")
        return prev

    prev.ok = False
    prev.state = MapVerifyState.FAILED.value
    prev.detail = f"apply not implemented for mode {mode}"
    return prev


def doctor_report() -> Dict[str, Any]:
    cap = detect_capabilities()
    return redact_secrets({
        "capability": cap.as_dict(),
        "modes": {
            "A_portfwd": "shared public IP + port → private",
            "B_nat": "1:1 when owned/authorized",
            "C_routed": "provider-routed; no invented routes",
            "D_wireguard": "optional tunnel; not public IPv4",
            "E_record": "DB only",
        },
        "verify_states": [s.value for s in MapVerifyState],
    })
