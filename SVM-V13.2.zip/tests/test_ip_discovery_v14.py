"""IP discovery + ips.txt atomic write tests."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from svm_ip_discovery import (
    DiscoveredAddr, merge_inventory, render_ips_txt, write_inventory,
    run_discovery, _classify,
)


def test_classify_private():
    assert _classify("10.1.2.3") == "private"
    assert _classify("100.64.0.5") == "cgnat"
    assert _classify("127.0.0.1") == "loopback"


def test_merge_preserves_manual():
    disc = [DiscoveredAddr("10.0.0.1", "inet", classification="private", source="host")]
    existing = [{"address": "10.0.0.99", "family": "inet", "source": "manual", "classification": "private"}]
    m = merge_inventory(disc, existing, allocated={"10.0.0.1"})
    addrs = {x.address for x in m}
    assert "10.0.0.1" in addrs and "10.0.0.99" in addrs
    assert any(x.address == "10.0.0.1" and x.verification == "allocated" for x in m)


def test_render_sections():
    addrs = [
        DiscoveredAddr("127.0.0.1", "inet", classification="loopback", source="host"),
        DiscoveredAddr("10.0.0.5", "inet", classification="private", source="host"),
    ]
    txt = render_ips_txt(addrs, hostname="test-host")
    assert "[PRIVATE_IPS]" in txt
    assert "10.0.0.5" in txt
    assert "NOT proof" in txt


def test_atomic_write(tmp_path):
    addrs = [DiscoveredAddr("10.0.0.7", "inet", classification="private", source="host", detected_at="t")]
    r = write_inventory(addrs, base_dir=str(tmp_path))
    assert r["ok"]
    assert (tmp_path / "ips.txt").exists()
    assert (tmp_path / "ips.json").exists()
    data = json.loads((tmp_path / "ips.json").read_text())
    assert data["count"] == 1
    # second write creates bak
    r2 = write_inventory(addrs, base_dir=str(tmp_path))
    assert r2["ok"]
    baks = list(tmp_path.glob("ips.txt.bak.*"))
    assert baks


def test_run_discovery(tmp_path):
    out = run_discovery(base_dir=str(tmp_path), include_egress=False)
    assert out["ok"]
    assert (tmp_path / "ips.txt").exists()
    # may be empty on restricted hosts but should not crash
    assert "count" in out
