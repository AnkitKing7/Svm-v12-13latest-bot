"""V14 topology + mapping engine tests."""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from svm_topology import classify_ipv4, detect_capabilities, TopologyClass, redact_secrets
from svm_map import MappingRequest, preview_mapping, apply_mapping, validate_request, doctor_report


class TestClassify:
    def test_ranges(self):
        assert classify_ipv4("10.0.0.1") == "private"
        assert classify_ipv4("100.64.1.1") == "cgnat"
        assert classify_ipv4("8.8.8.8") == "public"
        assert classify_ipv4("127.0.0.1") == "loopback"
        assert classify_ipv4("not-an-ip") == "invalid"


class TestCapability:
    def test_detect_runs(self):
        rep = detect_capabilities()
        assert rep.topology in {t.value for t in TopologyClass}
        assert "record" in rep.supported_modes
        d = rep.as_dict()
        assert "backend" in d

    def test_redact(self):
        assert redact_secrets({"password": "x", "ip": "1.2.3.4"})["password"] == "***REDACTED***"


class TestMapping:
    def test_record_preview(self):
        r = MappingRequest(mode="record", private_ip="10.0.0.5", dry_run=True)
        out = preview_mapping(r)
        assert out.ok
        assert out.state == "RECORDED"

    def test_portfwd_validation(self):
        r = MappingRequest(mode="portfwd", public_ip="127.0.0.1", private_ip="10.0.0.2")
        errs = validate_request(r)
        assert any("port" in e for e in errs)

    def test_portfwd_dry_run(self):
        r = MappingRequest(
            mode="portfwd",
            public_ip="127.0.0.1",
            private_ip="10.0.0.2",
            public_port=25565,
            private_port=25565,
            protocol="tcp",
            dry_run=True,
            operator_confirmed=False,
        )
        out = apply_mapping(r)
        assert out.ok
        assert out.preview

    def test_live_requires_confirm(self):
        r = MappingRequest(
            mode="portfwd",
            public_ip="127.0.0.1",
            private_ip="10.0.0.2",
            public_port=40111,
            private_port=22,
            dry_run=False,
            operator_confirmed=False,
        )
        out = apply_mapping(r)
        assert out.ok is False

    def test_routed_blocked_without_prereq(self):
        r = MappingRequest(
            mode="routed",
            public_ip="203.0.113.10",  # documentation range — not applied live
            private_ip="10.0.0.8",
            dry_run=True,
            operator_confirmed=True,
        )
        out = preview_mapping(r)
        assert out.ok is False or "routed" in (out.detail or "").lower() or out.errors

    def test_wireguard_not_public_ip(self):
        r = MappingRequest(mode="wireguard", dry_run=True, operator_confirmed=True)
        out = apply_mapping(r)
        assert "public IPv4" in out.detail or "NOT" in out.detail.upper() or "Tunnel" in out.detail

    def test_doctor(self):
        d = doctor_report()
        assert "capability" in d
        assert "modes" in d
